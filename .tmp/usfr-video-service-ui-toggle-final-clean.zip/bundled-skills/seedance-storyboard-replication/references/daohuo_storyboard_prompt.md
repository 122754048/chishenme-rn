# 故事板提示词：固定骨架 + 动态填充

这是 Skill 唯一的故事板生图模板。它不保存某个具体商品、人物或案例，而是固定成功验证过的 16:9 导演预制作指南结构；每次任务根据用户素材和已确认分镜动态填充。模板适用于实物产品、App/数字产品、服务、品牌和无产品内容，不把电商设为默认类型。

## 使用原则

- **固定骨架**：版式、素材职责、人物与目标证据一致性、短标签格式、文字限制、Negative Prompt。
- **动态填充**：内容类型、目标产品/服务类型、视频标题、时长、镜头数、适用的人物描述、目标证据锁定项、参考视频用途、逐 Cut 画面和精确标签。
- `@分镜脚本` 是镜头顺序、时间、动作和情绪的唯一来源，不得改剧情、重排 Cut 或增加无关镜头。
- 故事板图片只负责视觉确认。完整分镜脚本、口播和备注必须在提交 Seedance 时作为文本逐 Cut 传入。
- 生成前替换全部 `{{...}}` 字段；最终发送给 image2 的提示词不得保留未替换占位符。

## 动态字段

每次生成故事板前，根据当前任务填充：

| 字段 | 内容 |
|---|---|
| `{{CONTENT_TYPE}}` | 产品演示、App 广告、服务说明、品牌故事、教程、剧情、表演或其他已支持内容类型 |
| `{{PRODUCT_OR_SERVICE_TYPE}}` | 实物产品、App/数字产品、服务、品牌或 `none` |
| `{{VIDEO_TITLE}}` | 目标内容或视频主题的短标题 |
| `{{DURATION}}` | 视频总时长 |
| `{{SEGMENT_INDEX}}` | 当前故事板编号，例如 `1/2`；单段时写 `1/1` |
| `{{SEGMENT_DURATION}}` | 当前分段时长，必须为 4-15 秒 |
| `{{GLOBAL_CUT_RANGE}}` | 当前分段包含的全局 Cut 范围，例如 `Cut 1-4` |
| `{{SHOT_COUNT}}` | 已确认的 Cut 数量 |
| `{{TARGET_VIDEO_RATIO}}` | 成片比例，默认 9:16 |
| `{{CHARACTER_REFERENCE_ROLE}}` | 人物参考图编号、身份、脸、发型/头巾、服装和体型锁定项；无人设时写 `none` 或明确手部/纯环境策略 |
| `{{PRODUCT_REFERENCE_ROLE}}` | 实物产品、App、服务或品牌证据的编号、身份、结构和不可漂移项；不适用时写 `none` |
| `{{REFERENCE_VIDEO_ROLE}}` | 参考视频或关键帧板编号，以及只允许参考的节奏、运镜、构图和场景推进 |
| `{{VISUAL_STYLE}}` | 实拍风格、光线、质感和摄影语言 |
| `{{COLOR_PALETTE}}` | 主色板 |
| `{{ENVIRONMENT_PLAN}}` | 主要室内/户外环境、连续性和动线 |
| `{{CONTINUITY_MANIFEST}}` | 整套故事板共用的连续性清单，锁适用的人物、目标证据、场景、光线、屏幕方向和边界交接状态 |
| `{{INCOMING_CONTINUITY}}` | 当前分段开头承接上一段的状态；第一段写明起始状态 |
| `{{OUTGOING_CONTINUITY}}` | 当前分段结尾交给下一段的状态；最后一段写明结束状态 |
| `{{ADJACENT_BOARD_ROLE}}` | 相邻分段故事板的作用；无相邻分段时写 `none` |
| `{{SHOT_CARDS}}` | 按已确认顺序生成的全部 Cut 卡片 |
| `{{EXACT_LABELS}}` | 卡片与底栏允许出现的全部精确短文字 |
| `{{AUDIO_NOTE}}` | 口播、环境声、Foley、转场声和音乐策略 |
| `{{TRADEMARK_SAFETY_NOTE}}` | 商标安全策略；只保留目标证据中真实存在且允许使用的标识，禁止从参考视频复制品牌或凭空生成品牌文字 |
| `{{TASK_NEGATIVES}}` | 当前人物、目标证据和场景特有的禁止项 |

## 动态组装步骤

1. 读取 `analysis/input_slots.json` 的固定角色绑定。人物图只锁身份与造型；实物/App/服务/品牌素材只锁目标真值；参考视频只锁节奏、运镜、构图、动作功能和场景推进。未填槽位走 source KEEP，不重新识别或猜测职责；不适用的职责写 `none`。
2. 只把当前分段的已确认语义 Cut 转成 `{{SHOT_CARDS}}`，镜头数量必须等于 `{{SHOT_COUNT}}`。保留全局 Cut 编号和分段内时间码。`excluded_app_end_card`、source-origin `opaque_ui_demo`、`source_ui_keep` 与 `generated_ui_demo` 不生成故事板卡；`generated_ui_demo` 由确定性 UI renderer/timeline lane 单独承载。若需要复刻设备外壳、手部或人物动作，只把这些非 UI 部分作为 ordinary generated region 规划。
3. 每个 Cut 从完整脚本提炼一个关键动作和一个必要约束，生成短标签并汇总为 `{{EXACT_LABELS}}`。
4. 默认使用简短大写英文标签降低小字变形风险；用户明确要求其他语言时才切换。
5. `generated_ui_demo` 不进入语义脚本、故事板、Image Gen 或 Seedance；只生成 UI truth、状态/交互时间轴和确定性 renderer 的输入。完整 UI 文案由用户真实 UI 像素或确定性后期层承载，不依赖模型绘制复杂小字。
6. 填写 `{{CONTINUITY_MANIFEST}}`、`{{INCOMING_CONTINUITY}}`、`{{OUTGOING_CONTINUITY}}` 和 `{{ADJACENT_BOARD_ROLE}}`。第二段必须参考第一段故事板和原始适用证据，不得重新发明人物、目标产品/App/服务/品牌或场景。
7. 检查人物、目标证据、场景和光线连续性，删除与本任务无关的通用描述。
8. 填写 `{{TRADEMARK_SAFETY_NOTE}}`。若曾触发 `PROVIDER_MODERATION_ERROR: TRADEMARK`，必须先向用户说明：只改提示词可能不足；不得静默删除目标 Logo，需用户同意后才能使用去品牌或替换素材重做故事板。
9. 替换全部占位符后再调用 image2。不要把本文件连同未填字段原样提交。

## 固定版式

最终输出是一张专业、电影化、网格清晰的 `16:9` 横版电影制作板，而不是普通九宫格或竖屏截图拼图。

必须包含：

1. **共享创意指导**：顶部栏显示标题、`{{SHOT_COUNT}}`、`{{TARGET_VIDEO_RATIO}}`、统一调色板和拍摄方式。
2. **角色与风格参考**：有人物图时展示人物多角度；无人设时不虚构人物区。
3. **人物细节特写**：仅在适用时展示脸部/眼部、手部、头发或头巾、服装材质和关键配饰。
4. **目标证据区**：按类型展示实物结构/材质、App 真实页面结构、服务证明物或品牌视觉资产；不适用时标为 `none`。
5. **环境和场景设计**：主要环境氛围，以及简洁的俯视动线示意图，标出摄像机位置、主体方向和目标证据位置。
6. **故事板分镜区**：按 Cut 顺序展示全部生成镜头，分镜图只保留 Cut、时间、重要事项和必要约束。
7. **灯光/情绪/风格备注**：使用色块、光线图标和短标签表达。
8. **情绪和关键词块**：只使用少量关键词。
9. **音频/音调部分**：口播、环境/动作声、Foley、转场声和是否有音乐。
10. **电影摄影笔记**：用短标签表示镜头特性、运动风格和后期感觉。

不要在故事板图片中排版完整分镜脚本、长段口播、复杂 UI 文案或密集备注。不要依赖故事板图片中的文字向 Seedance 传递剧情。

## Cut 卡片格式

每个 Cut 卡片必须包含一张主画面和一条干净说明条：

```text
Cut {{CUT_NUMBER}}
画面：{{COMPLETE_VISUAL_DESCRIPTION_FOR_IMAGE_GENERATION}}
标签："{{NN}}  {{START}}-{{END}}  {{KEY_ACTION_TAG}} · {{IDENTITY_OR_PRODUCT_LOCK_TAG}}"
```

标签只表达重要事项：

- `{{KEY_ACTION_TAG}}`：当前镜头唯一关键动作，例如 `SEARCH`、`REVEAL`、`TEXTURE`、`COMPARE`。
- `{{IDENTITY_OR_PRODUCT_LOCK_TAG}}`：最容易漂移的一项，例如 `KEEP FACE`、`SAME PRODUCT`、`UI STATE LOCK`、`TRUE SCALE`。
- 标签必须短、粗、清晰；不放口播，不放完整脚本，不放复杂 UI 文案或声音细节。

## 可提交给 image2 的固定提示词骨架

```text
Use case: infographic-diagram
Asset type: 16:9 cinematic pre-production storyboard / visual planning board for Segment {{SEGMENT_INDEX}} of a {{DURATION}} {{CONTENT_TYPE}} featuring {{PRODUCT_OR_SERVICE_TYPE}}. Current segment duration: {{SEGMENT_DURATION}}.

Input roles:
- Character reference: {{CHARACTER_REFERENCE_ROLE}}
- Product/App/service/brand reference: {{PRODUCT_REFERENCE_ROLE}}
- Reference video or contact sheet: {{REFERENCE_VIDEO_ROLE}}

Primary request:
Create one polished landscape 16:9 director's production board for Segment {{SEGMENT_INDEX}} of a {{TARGET_VIDEO_RATIO}} {{CONTENT_TYPE}} about {{PRODUCT_OR_SERVICE_TYPE}}, titled "{{VIDEO_TITLE}}". This board covers {{GLOBAL_CUT_RANGE}} only. Use a professional modular grid, clear hierarchy, generous spacing, and realistic pre-production design. This must feel like a director's visual guide, not a plain nine-grid.

Fixed layout:
- Top: shared creative direction with title, Segment {{SEGMENT_INDEX}}, {{GLOBAL_CUT_RANGE}}, {{SHOT_COUNT}} shots, target ratio, palette, environment, and camera style.
- Left: CHARACTER section only when applicable, with identity/style evidence and required detail views.
- Center: STORYBOARD section containing exactly {{SHOT_COUNT}} ordered generated Cut cards.
- Right: TARGET EVIDENCE section for the applicable physical product, App, service, brand, or `none`, plus a simple top-down camera movement diagram.
- Bottom: large short labels for lighting, camera, palette, audio/tone, mood keywords, and cinematography notes.

Environment and movement:
{{ENVIRONMENT_PLAN}}

Shared continuity manifest:
{{CONTINUITY_MANIFEST}}

Segment continuity:
- Incoming state: {{INCOMING_CONTINUITY}}
- Outgoing state: {{OUTGOING_CONTINUITY}}
- Adjacent board role: {{ADJACENT_BOARD_ROLE}}

Storyboard cards:
{{SHOT_CARDS}}

Visual style:
{{VISUAL_STYLE}}
Color palette: {{COLOR_PALETTE}}
Audio direction: {{AUDIO_NOTE}}
Trademark safety: {{TRADEMARK_SAFETY_NOTE}}

Exact allowed text:
{{EXACT_LABELS}}

Identity and target-evidence locks:
For every populated fixed slot, preserve the applicable authorized character
identity and target physical-product/App/service/brand evidence. For an absent
slot, keep the corresponding source identity/product/UI truth as a source
KEEP layer instead of inventing a replacement. Preserve supplied geometry,
material, logo placement, UI state, approved short copy, service proof, scale,
and real use/interaction method where applicable. Do not send source UI or
source tail pixels to a provider.
Maintain the continuity manifest exactly across segment boards: same applicable subject state, target evidence state, environment direction, lighting, screen direction, prop positions, and action handoff. Segment boards are independent images for separate Seedance tasks, but they must read as one continuous story.

Brand rule:
Do not invent brand names, fake logos, trademark text, branded signage, UI copy, or packaging claims. Do not copy any branding from the reference video. Preserve only marks genuinely visible in authorized target evidence unless the user explicitly approves a compliant debranded or replacement asset after moderation failure.

UI rule:
generated_ui_demo is excluded from the semantic script and every storyboard. Route it to the deterministic UI renderer/timeline lane after the ordinary generated shell has been produced. The renderer consumes the approved page/state/layout contract and real target pixels or an authorized deterministic UI layer; it owns all readable UI copy and animation timing. Do not create cards for `excluded_app_end_card`, source-origin `opaque_ui_demo`, `source_ui_keep`, or `generated_ui_demo` intervals.

Text constraints:
Render only the exact allowed text. Use large crisp high-contrast sans-serif type on clean solid caption strips. No paragraphs, no dialogue, no complete script, no tiny filler text, no pseudo-text, and no unapproved UI copy. If optional text cannot be rendered accurately, leave the area blank instead of inventing characters.

Avoid:
garbled text, pseudo-writing, dense paragraphs, subtitles inside scene images, watermark, extra storyboard panels, reordered shots, identity drift, changed face, extra people, malformed hands, extra fingers, target evidence deformation, wrong product category, wrong UI state, changed color, fake logo, duplicate product, floating product, unrelated props, random scene changes, anime, illustration, plastic skin, hard-sell poster, shopping banner, {{TASK_NEGATIVES}}.
```

## 提交前检查

- `{{SHOT_CARDS}}` 中 Cut 数量与已确认脚本及区域路由一致；`excluded_app_end_card`、source-origin `opaque_ui_demo` 与 `source_ui_keep` 没有生成卡。
- `{{CONTENT_TYPE}}`、`{{PRODUCT_OR_SERVICE_TYPE}}`、`{{SEGMENT_INDEX}}`、`{{SEGMENT_DURATION}}` 和 `{{GLOBAL_CUT_RANGE}}` 已填写，且只覆盖当前分段。
- `{{CONTINUITY_MANIFEST}}`、`{{INCOMING_CONTINUITY}}`、`{{OUTGOING_CONTINUITY}}` 和 `{{ADJACENT_BOARD_ROLE}}` 已填写。
- 所有镜头顺序、时间和动作均来自已确认脚本。
- 人物、目标证据和参考视频职责没有混用；不适用的角色明确写 `none`。
- generated_ui_demo is excluded from the semantic script and every storyboard; its UI pixels and interaction timing are produced only by the deterministic UI renderer/timeline lane.
- `{{EXACT_LABELS}}` 只包含短标签，没有完整分镜脚本、口播或复杂 UI 文案。
- `{{TRADEMARK_SAFETY_NOTE}}` 已填写，且不会复制参考视频品牌或凭空创造品牌。
- 所有 `{{...}}` 已替换，提示词中没有占位符残留。
- 故事板图片比例为 16:9，成片目标比例单独写明。
- 目标证据 fidelity 优先于视觉新奇，人物一致性仅在人物适用时优先于姿势变化。
- 默认只规划口播、环境声、动作声、Foley 和转场声，不默认添加背景音乐。
## Revision-scoped Cut outputs

Storyboard generation is revision-scoped and Cut-scoped. Every approved Cut may
have its own PNG and sidecars under `storyboards/r{revision}/cuts/{cut_id}`;
there is no one-or-two image limit for storyboard Cuts. The optional
`overview.png` is a review convenience only and never an authoritative
Seedance reference. Seedance binds the ordered per-Cut SHA-256 values from the
immutable manifest. Partial regeneration may reuse unchanged Cuts and expands
continuity neighbors when requested; downstream Prompt and provider artifacts
must be regenerated whenever the manifest or any Cut SHA changes.
