from __future__ import annotations

import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

import pytest
import fakeredis
from jsonschema import Draft202012Validator

from server.errors import ReplicationError
from server.ephemeral_worker import EphemeralStageContext
from server.job_models import ArtifactRef
from server.public_job_projection import _script_review, _storyboard_review, project_public_job
from server.redis_job_store import RedisEphemeralJobStore
from server.review_models import RevisionManifest


class _ObjectStore:
    def __init__(self, objects: dict[str, bytes]) -> None:
        self.objects = objects

    def download_to(self, *, object_key: str, destination: Path, expected_sha256: str) -> Path:
        data = self.objects[object_key]
        assert hashlib.sha256(data).hexdigest() == expected_sha256
        destination.write_bytes(data)
        return destination

    def signed_get(self, *, object_key: str, expires_seconds: int) -> str:
        assert expires_seconds == 900
        return f"https://downloads.example/{object_key}"


class _JobStore:
    def __init__(self, artifacts: tuple[ArtifactRef, ...] = (), revisions: dict[str, object] | None = None) -> None:
        self.artifacts = list(artifacts)
        self.revisions = revisions or {}
        self.list_artifact_calls = 0
        self.get_artifact_calls = 0

    def list_artifacts(self, job_id: str) -> tuple[ArtifactRef, ...]:
        del job_id
        self.list_artifact_calls += 1
        return tuple(self.artifacts)

    def put_artifact(self, *, job_id: str, artifact: ArtifactRef) -> ArtifactRef:
        del job_id
        self.artifacts.append(artifact)
        return artifact

    def get_current_revision(self, job_id: str, kind: str) -> object | None:
        del job_id
        return self.revisions.get(kind)

    def get_artifact(self, job_id: str, artifact_id: str) -> ArtifactRef | None:
        del job_id
        self.get_artifact_calls += 1
        return next((artifact for artifact in self.artifacts if artifact.artifact_id == artifact_id), None)


class _TemporaryStore:
    def put_stream(self, *, job_id: str, logical_path: str, stream: object, content_type: str, expected_sha256: str) -> ArtifactRef:
        data = stream.read()  # type: ignore[union-attr]
        assert hashlib.sha256(data).hexdigest() == expected_sha256
        return ArtifactRef(
            artifact_id=logical_path,
            kind="temporary",
            object_key=f"temporary/{job_id}/{logical_path}",
            sha256=expected_sha256,
            content_type=content_type,
            size_bytes=len(data),
        )


def test_context_publish_keeps_equal_png_bytes_distinct_per_segment_and_idempotent_per_segment(tmp_path: Path) -> None:
    job_id = "job-123"
    jobs = RedisEphemeralJobStore(fakeredis.FakeRedis(decode_responses=False), prefix="review-contract")
    snapshot = jobs.create_job(
        job_id=job_id,
        slots_manifest={},
        capability_token_hash="a" * 64,
        ttl_seconds=3600,
    )
    context = EphemeralStageContext(
        job_id=job_id,
        stage="generate_storyboards",
        snapshot=snapshot,
        job_store=jobs,
        temporary_store=_TemporaryStore(),
        work_dir=tmp_path,
    )
    png = b"same-png-bytes"
    common = {
        "presentation": "image_set",
        "approval_scope": "all_segments_together",
        "text_only_substitute_forbidden": True,
        "storyboard_manifest_sha256": "b" * 64,
    }
    first = context.publish_bytes(
        kind="storyboard_image",
        data=png,
        content_type="image/png",
        expected_sha256=hashlib.sha256(png).hexdigest(),
        metadata={**common, "segment_id": "S01", "logical_name": "storyboards/segment_01_v1.png"},
    )
    second = context.publish_bytes(
        kind="storyboard_image",
        data=png,
        content_type="image/png",
        expected_sha256=hashlib.sha256(png).hexdigest(),
        metadata={**common, "segment_id": "S02", "logical_name": "storyboards/segment_02_v1.png"},
    )
    replay = context.publish_bytes(
        kind="storyboard_image",
        data=png,
        content_type="image/png",
        expected_sha256=hashlib.sha256(png).hexdigest(),
        metadata={**common, "segment_id": "S01", "logical_name": "storyboards/segment_01_v1.png"},
    )

    assert first["artifact_id"] != second["artifact_id"]
    assert first["object_key"] != second["object_key"]
    assert replay == first
    assert {item.artifact_id for item in jobs.list_artifacts(job_id)} == {
        first["artifact_id"],
        second["artifact_id"],
    }


def test_script_review_exposes_downloadable_markdown_artifact_without_inline_content() -> None:
    job_id = "job-123"
    revision_key = f"temporary/{job_id}/reviews/script-1.json"
    body = json.dumps(
        {
            "cuts": [
                {
                    "cut_id": "C01",
                    "start_ms": 0,
                    "end_ms": 800,
                    "scene": "creator scene",
                    "action": "presents the product",
                    "camera": "medium close-up",
                    "dialogue": "Try it",
                    "delivery": "natural",
                }
            ],
            "visible_text_locks": [],
        },
        ensure_ascii=False,
    ).encode("utf-8")
    document = ArtifactRef(
        artifact_id="script-document",
        kind="user_script_markdown",
        object_key=f"temporary/{job_id}/stages/build_script/script-document",
        sha256="a" * 64,
        content_type="text/markdown; charset=utf-8",
        size_bytes=1,
        metadata={
            "logical_name": "analysis/reverse_storyboard_script.md",
            "presentation": "file",
            "inline_chat_substitute_forbidden": True,
        },
    )
    manifest = SimpleNamespace(
        object_key=revision_key,
        sha256=hashlib.sha256(body).hexdigest(),
        user_artifact_id=document.artifact_id,
        user_artifact_object_key=document.object_key,
        user_artifact_sha256=document.sha256,
    )

    review = _script_review(
        job_store=_JobStore((document,)),
        object_store=_ObjectStore({revision_key: body}),
        job_id=job_id,
        manifest=manifest,
    )

    assert review == {
        "type": "script",
        "artifact": {
            "logical_name": "analysis/reverse_storyboard_script.md",
            "presentation": "file",
            "content_type": "text/markdown; charset=utf-8",
            "download_url": f"/api/v1/jobs/{job_id}/artifacts/analysis/reverse_storyboard_script.md",
        },
    }


def test_script_review_rejects_a_download_binding_outside_the_exact_logical_name() -> None:
    job_id = "job-123"
    artifact = ArtifactRef(
        artifact_id="script-document",
        kind="user_script_markdown",
        object_key=f"temporary/{job_id}/stages/build_script/script-document",
        sha256="a" * 64,
        content_type="text/markdown; charset=utf-8",
        size_bytes=1,
        metadata={
            "logical_name": "analysis/other_document.md",
            "presentation": "file",
            "inline_chat_substitute_forbidden": True,
        },
    )
    manifest = SimpleNamespace(
        user_artifact_id=artifact.artifact_id,
        user_artifact_object_key=artifact.object_key,
        user_artifact_sha256=artifact.sha256,
    )

    with pytest.raises(ReplicationError, match="review artifact binding is invalid"):
        _script_review(
            job_store=_JobStore((artifact,)),
            object_store=_ObjectStore({}),
            job_id=job_id,
            manifest=manifest,
        )


def test_script_review_accepts_the_server_published_logical_name_binding() -> None:
    job_id = "job-123"
    artifact = ArtifactRef(
        artifact_id="script-document",
        kind="user_script_markdown",
        object_key=f"temporary/{job_id}/stages/build_script/script-document",
        sha256="a" * 64,
        content_type="text/markdown; charset=utf-8",
        size_bytes=1,
        metadata={
            "logical_name": "analysis/reverse_storyboard_script.md",
            "presentation": "file",
            "inline_chat_substitute_forbidden": True,
        },
    )
    manifest = SimpleNamespace(
        user_artifact_id="script-document",
        user_artifact_object_key=artifact.object_key,
        user_artifact_sha256=artifact.sha256,
    )

    review = _script_review(
        job_store=_JobStore((artifact,)),
        object_store=_ObjectStore({}),
        job_id=job_id,
        manifest=manifest,
    )

    assert review["artifact"]["download_url"] == (
        f"/api/v1/jobs/{job_id}/artifacts/analysis/reverse_storyboard_script.md"
    )


def test_script_review_uses_exact_artifact_lookup_instead_of_scanning_the_job_ledger() -> None:
    job_id = "job-123"
    artifact = ArtifactRef(
        artifact_id="script-document",
        kind="user_script_markdown",
        object_key=f"temporary/{job_id}/stages/build_script/script-document",
        sha256="a" * 64,
        content_type="text/markdown; charset=utf-8",
        size_bytes=1,
        metadata={
            "logical_name": "analysis/reverse_storyboard_script.md",
            "presentation": "file",
            "inline_chat_substitute_forbidden": True,
        },
    )
    jobs = _JobStore((artifact,))

    _script_review(
        job_store=jobs,
        object_store=_ObjectStore({}),
        job_id=job_id,
        manifest=SimpleNamespace(
            user_artifact_id=artifact.artifact_id,
            user_artifact_object_key=artifact.object_key,
            user_artifact_sha256=artifact.sha256,
        ),
    )

    assert jobs.get_artifact_calls == 1
    assert jobs.list_artifact_calls == 0


def test_context_published_script_document_projects_through_opaque_logical_download_url(tmp_path: Path) -> None:
    job_id = "job-123"
    jobs = _JobStore()
    context = EphemeralStageContext(
        job_id=job_id,
        stage="build_script",
        snapshot=SimpleNamespace(),
        job_store=jobs,
        temporary_store=_TemporaryStore(),
        work_dir=tmp_path,
    )
    body = b"# review script\n"
    published = context.publish_bytes(
        kind="user_script_markdown",
        data=body,
        content_type="text/markdown; charset=utf-8",
        expected_sha256=hashlib.sha256(body).hexdigest(),
        metadata={
            "logical_name": "analysis/reverse_storyboard_script.md",
            "presentation": "file",
            "inline_chat_substitute_forbidden": True,
        },
    )
    manifest = RevisionManifest(
        kind="script",
        revision=1,
        object_key="temporary/job-123/stages/build_script/revision",
        sha256="b" * 64,
        inputs_sha256="c" * 64,
        user_artifact_id=published["artifact_id"],
        user_artifact_object_key=published["object_key"],
        user_artifact_sha256=published["sha256"],
    )
    jobs.revisions["script"] = manifest
    snapshot = SimpleNamespace(
        job_id=job_id,
        state="RUNNING",
        pending_review_request=None,
        approved_script_sha256=None,
        approved_storyboard_sha256=None,
    )

    projection = project_public_job(snapshot, job_store=jobs, object_store=_ObjectStore({}))

    assert projection["review"]["artifact"]["download_url"] == (
        f"/api/v1/jobs/{job_id}/artifacts/analysis/reverse_storyboard_script.md"
    )
    assert "/stages/" not in projection["review"]["artifact"]["download_url"]


def test_storyboard_review_exposes_png_image_set_for_one_group_approval() -> None:
    job_id = "job-123"
    image = ArtifactRef(
        artifact_id="storyboard-image",
        kind="storyboard_image",
        object_key=f"temporary/{job_id}/stages/generate_storyboards/storyboard-image",
        sha256="a" * 64,
        content_type="image/png",
        size_bytes=1,
        metadata={
            "logical_name": "storyboards/segment_01_v2.png",
            "presentation": "image_set",
            "approval_scope": "all_segments_together",
            "text_only_substitute_forbidden": True,
            "storyboard_manifest_sha256": "b" * 64,
        },
    )
    manifest = SimpleNamespace(
        sha256="b" * 64,
        presentation="image_set",
        approval_scope="all_segments_together",
        text_only_substitute_forbidden=True,
        cut_images=(
            SimpleNamespace(
                artifact_id=image.artifact_id,
                object_key=image.object_key,
                sha256=image.sha256,
                logical_name="storyboards/segment_01_v2.png",
            ),
        ),
        grid_object_key=None,
    )

    review = _storyboard_review(
        job_store=_JobStore((image,)),
        object_store=_ObjectStore({}),
        job_id=job_id,
        manifest=manifest,
    )

    assert review == {
        "type": "storyboard",
        "artifact": {
            "presentation": "image_set",
            "approval_scope": "all_segments_together",
            "text_only_substitute_forbidden": True,
            "images": [
                {
                    "logical_name": "storyboards/segment_01_v2.png",
                    "content_type": "image/png",
                    "url": f"/api/v1/jobs/{job_id}/artifacts/storyboards/segment_01_v2.png",
                }
            ],
        },
    }


def test_storyboard_review_rejects_manifest_without_complete_collection_metadata() -> None:
    job_id = "job-123"
    manifest = SimpleNamespace(
        sha256="b" * 64,
        cut_images=(
            SimpleNamespace(
                object_key=f"temporary/{job_id}/storyboards/segment_01_v2.png",
                logical_name="storyboards/segment_01_v2.png",
            ),
        ),
        grid_object_key=None,
    )
    snapshot = SimpleNamespace(
        job_id=job_id,
        state="RUNNING",
        pending_review_request=None,
        approved_script_sha256=None,
        approved_storyboard_sha256=None,
    )

    with pytest.raises(ReplicationError, match="storyboard review binding is invalid"):
        project_public_job(
            snapshot,
            job_store=_JobStore(revisions={"storyboard": manifest}),
            object_store=_ObjectStore({}),
        )


def test_storyboard_review_requires_server_published_image_bindings() -> None:
    job_id = "job-123"
    manifest = SimpleNamespace(
        sha256="b" * 64,
        presentation="image_set",
        approval_scope="all_segments_together",
        text_only_substitute_forbidden=True,
        cut_images=(
            SimpleNamespace(
                artifact_id="storyboard-image",
                object_key=f"temporary/{job_id}/stages/generate_storyboards/storyboard-image",
                sha256="a" * 64,
                logical_name="storyboards/segment_01_v2.png",
            ),
        ),
        grid_object_key=None,
    )
    snapshot = SimpleNamespace(
        job_id=job_id,
        state="RUNNING",
        pending_review_request=None,
        approved_script_sha256=None,
        approved_storyboard_sha256=None,
    )

    with pytest.raises(ReplicationError, match="review artifact binding is invalid"):
        project_public_job(
            snapshot,
            job_store=_JobStore(revisions={"storyboard": manifest}),
            object_store=_ObjectStore({}),
        )


def test_storyboard_review_keeps_two_logical_segments_that_share_png_bytes() -> None:
    job_id = "job-123"
    shared_sha256 = "a" * 64
    images = tuple(
        ArtifactRef(
            artifact_id=f"storyboard-image-{number}",
            kind="storyboard_image",
            object_key=f"temporary/{job_id}/stages/generate_storyboards/storyboard-image-{number}",
            sha256=shared_sha256,
            content_type="image/png",
            size_bytes=1,
            metadata={
                "logical_name": f"storyboards/segment_{number:02d}_v2.png",
                "presentation": "image_set",
                "approval_scope": "all_segments_together",
                "text_only_substitute_forbidden": True,
                "storyboard_manifest_sha256": "b" * 64,
            },
        )
        for number in (1, 2)
    )
    manifest = SimpleNamespace(
        sha256="b" * 64,
        presentation="image_set",
        approval_scope="all_segments_together",
        text_only_substitute_forbidden=True,
        cut_images=(
            SimpleNamespace(artifact_id=images[0].artifact_id, object_key=images[0].object_key, sha256=shared_sha256, logical_name="storyboards/segment_01_v2.png"),
            SimpleNamespace(artifact_id=images[1].artifact_id, object_key=images[1].object_key, sha256=shared_sha256, logical_name="storyboards/segment_02_v2.png"),
        ),
        grid_object_key=None,
    )

    review = _storyboard_review(job_store=_JobStore(images), object_store=_ObjectStore({}), job_id=job_id, manifest=manifest)

    assert [image["logical_name"] for image in review["artifact"]["images"]] == [
        "storyboards/segment_01_v2.png",
        "storyboards/segment_02_v2.png",
    ]


def test_storyboard_review_rejects_duplicate_logical_names() -> None:
    job_id = "job-123"
    manifest = SimpleNamespace(
        presentation="image_set",
        approval_scope="all_segments_together",
        text_only_substitute_forbidden=True,
        cut_images=(
            SimpleNamespace(
                object_key=f"temporary/{job_id}/storyboards/a.png",
                logical_name="storyboards/segment_01_v2.png",
            ),
            SimpleNamespace(
                object_key=f"temporary/{job_id}/storyboards/b.png",
                logical_name="storyboards/segment_01_v2.png",
            ),
        ),
        grid_object_key=None,
    )

    with pytest.raises(ReplicationError, match="duplicate storyboard logical name"):
        _storyboard_review(job_store=_JobStore(), object_store=_ObjectStore({}), job_id=job_id, manifest=manifest)


def test_case_catalog_keeps_two_artifact_approvals_for_every_generated_route() -> None:
    catalog = json.loads((Path(__file__).parent / "case_catalog.json").read_text(encoding="utf-8"))

    for case in catalog["cases"]:
        if case["route"] in {"route_1", "route_2"}:
            assert case["expected"]["approval_count"] == 2, case["case_id"]
        else:
            assert case["route"] == "local_only"
            assert case["case_id"] == "A09"
            assert case["expected"]["approval_count"] == 0


def test_revision_schemas_keep_legacy_revisions_compatible_but_require_complete_new_contracts() -> None:
    root = Path(__file__).parents[1] / "schemas"
    script = json.loads((root / "script_revision.schema.json").read_text(encoding="utf-8"))
    storyboard = json.loads((root / "storyboard_revision.schema.json").read_text(encoding="utf-8"))
    digest = "a" * 64
    cut = {
        "cut_id": "C01", "start_ms": 0, "end_ms": 1, "scene": "scene", "action": "action",
        "camera": "camera", "dialogue": "dialogue", "delivery": "delivery", "audio_events": [],
        "selling_point": {}, "proof": {}, "visual": "visual", "evidence_ids": [], "route": "route_2",
    }
    legacy_script = {"kind": "script", "revision": 1, "object_key": "legacy.json", "sha256": digest, "inputs_sha256": digest, "cuts": [cut]}
    new_script = {
        **legacy_script,
        "user_artifact_id": "script-artifact",
        "user_artifact_object_key": "temporary/job/stages/build_script/script-artifact",
        "user_artifact_sha256": digest,
    }
    legacy_storyboard = {
        "kind": "storyboard", "revision": 1, "object_key": "legacy.json", "sha256": digest,
        "inputs_sha256": digest,
        "cut_images": [{"cut_id": "C01", "object_key": "legacy.png", "sha256": digest, "width": 1, "height": 1}],
    }
    new_storyboard = {
        **legacy_storyboard,
        "presentation": "image_set", "approval_scope": "all_segments_together",
        "text_only_substitute_forbidden": True,
        "cut_images": [{
            "cut_id": "C01", "artifact_id": "storyboard-artifact", "object_key": "temporary/job/stages/generate/storyboard-artifact",
            "sha256": digest, "width": 1, "height": 1, "logical_name": "storyboards/segment_01_v1.png",
        }],
    }

    script_validator = Draft202012Validator(script)
    storyboard_validator = Draft202012Validator(storyboard)
    assert not list(script_validator.iter_errors(legacy_script))
    assert not list(script_validator.iter_errors(new_script))
    assert list(script_validator.iter_errors({**new_script, "user_artifact_sha256": None}))
    assert not list(storyboard_validator.iter_errors(legacy_storyboard))
    assert not list(storyboard_validator.iter_errors(new_storyboard))
    assert list(storyboard_validator.iter_errors({**new_storyboard, "approval_scope": None}))
    assert list(storyboard_validator.iter_errors({
        **legacy_storyboard,
        "cut_images": [{
            **legacy_storyboard["cut_images"][0],
            "logical_name": "storyboards/segment_01_v1.png",
        }],
    }))
