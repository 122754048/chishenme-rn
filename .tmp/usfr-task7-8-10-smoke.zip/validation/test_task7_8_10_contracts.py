from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pytest

from server.qc_escalation import build_qc_plan, build_qc_receipt, validate_focused_qc_result
from server.telemetry import MetricsSink
from validation.performance.route_first_benchmark import build_comparison_report
from scripts.package_release import archive_entries


SHA = "a" * 64


def test_focused_qc_rejects_full_rerun_and_requires_bound_receipt() -> None:
    plan = build_qc_plan(
        route="standard",
        hard_failures=["BLACK_FRAME_DETECTED"],
        factor_scores={"motion": {"score": 80}, "identity": {"score": 99}},
    )
    receipt = build_qc_receipt(
        plan=plan,
        final_output_sha256=SHA,
        source_evidence_sha256s=["b" * 64],
        evaluator_identity={"model_sha256": "c" * 64},
        factor_scores={"motion": {"score": 91}},
    )
    with pytest.raises(ValueError, match="full rerun"):
        validate_focused_qc_result(
            plan=plan,
            result={"evaluated_factors": ["motion"], "full_rerun": True, "receipt": receipt},
        )
    assert validate_focused_qc_result(
        plan=plan,
        result={"evaluated_factors": ["motion"], "full_rerun": False, "receipt": receipt},
    )["receipt"]["final_output_sha256"] == SHA


def test_telemetry_exports_real_report_and_benchmark_envelopes() -> None:
    sink = MetricsSink()
    sink.record(
        run_id="candidate",
        stage="seedance",
        route="standard",
        attempt=1,
        status="succeeded",
        duration_seconds=5,
        phase="wait",
        request_digest=SHA,
        provider_task_id="provider-1",
        provider=True,
        temporary_files=2,
        temporary_bytes=10,
        decoded_frames=4,
    )
    candidate = sink.build_run_report("candidate", quality=100, hard_failures=[])
    baseline = {**candidate, "run_id": "baseline", "active_seconds": 10, "videos": 1}
    candidate["active_seconds"] = 5
    candidate["videos"] = 1
    report = build_comparison_report(baseline=baseline, candidate=candidate)
    assert candidate["provider_calls"]["seedance"] == 1
    assert candidate["provider_wait_seconds"] == 5
    assert report["comparison"]["passed"] is True


def test_release_archive_entries_exclude_cache_history_and_secret_files(tmp_path: Path) -> None:
    (tmp_path / "server").mkdir()
    (tmp_path / "server" / "app.py").write_text("print('ok')\n", encoding="utf-8")
    (tmp_path / "replication_runs").mkdir()
    (tmp_path / "replication_runs" / "source.mp4").write_bytes(b"media")
    (tmp_path / ".pytest_cache").mkdir()
    (tmp_path / ".pytest_cache" / "state").write_text("cache", encoding="utf-8")
    (tmp_path / ".env").write_text("SECRET=value", encoding="utf-8")
    assert archive_entries(tmp_path) == ["server/app.py"]
