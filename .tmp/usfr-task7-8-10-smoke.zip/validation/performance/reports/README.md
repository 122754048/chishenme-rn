# Route-first performance reports

Use `server.telemetry.MetricsSink` to export one path-free run report for the
baseline and one for the candidate. The record includes route, attempt,
duration, status, request digest, provider task ID, active/wait split,
temporary files/bytes, decoded frames, provider calls, QC escalations, quality,
and hard gates. Feed those JSON reports to `route_first_benchmark.py`; no
profile may be promoted from synthetic or missing baseline/candidate evidence.

The report intentionally stores digests and provider task IDs, never API keys
or raw private inputs. Docker and real-provider acceptance stay `not_run`
until actually executed in the target environment.
