from __future__ import annotations

from types import SimpleNamespace

import pytest

from server.ephemeral_worker import EphemeralWorkerManager
from server.errors import ReplicationError


def _manager() -> EphemeralWorkerManager:
    return EphemeralWorkerManager(
        job_store=None,
        temporary_store=None,
        stage_ports={"run_tts": lambda: None, "run_final_lip_sync": lambda: None},
        profile_bundle_resolver=SimpleNamespace(immutable=True),
        capability_ports={},
    )


def test_active_production_readiness_rejects_unbound_runtime_capabilities(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("USFR_PROFILE_MODE", "active")

    with pytest.raises(ReplicationError, match="active production"):
        _manager().validate_startup_capabilities()


def test_shadow_readiness_keeps_legacy_callable_compatibility(
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    monkeypatch.setenv("USFR_PROFILE_MODE", "shadow")

    _manager().validate_startup_capabilities()

