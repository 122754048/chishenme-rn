from __future__ import annotations

from collections.abc import Mapping
from contextlib import contextmanager
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace

import pytest

from server import packaged_ports, packaged_stages
from server.ephemeral_driver import EXECUTABLE_STAGES, POST_APPROVAL_STAGES
from server.errors import ReplicationError
from server.orchestrator import build_semantic_stage_mapping, build_stage_plan
from server.runninghub_workflows import RunningHubWorkflowClient


def _language_only_manifest() -> dict[str, object]:
    return {
        "admission": {"can_proceed": True, "language_only": True},
        "output_language": "ko-KR",
        "routes": {},
        "slots": {},
        "extensions": {},
        "review_route": "route_2",
    }


def test_language_only_no_seedance_keeps_route_2_and_two_approvals() -> None:
    plan = build_stage_plan(_language_only_manifest())
    names = [stage["name"] for stage in plan]

    assert names == [
        "bind_inputs",
        "probe_source",
        "analyze_dynamics",
        "route_regions",
        "build_script",
        "await_script_approval",
        "generate_storyboards",
        "await_storyboard_approval",
        "run_tts",
        "validate_tts_language",
        "run_final_lip_sync",
        "splice_timeline",
        "run_qc",
    ]
    assert {stage["review_route"] for stage in plan} == {"route_2"}
    assert names.count("await_script_approval") == 1
    assert names.count("await_storyboard_approval") == 1
    assert {
        "compile_seedance20_prompt",
        "audit_seedance_request",
        "submit_provider_video",
        "wait_provider_video",
    }.isdisjoint(names)

    semantic = build_semantic_stage_mapping(plan)
    assert semantic["user_approval_count"] == 2
    assert semantic["provider_stage_entry_count"] == 2


def _workflow_client(
    responses: list[Mapping[str, object]],
    calls: list[dict[str, object]],
    *,
    result_bytes: bytes,
) -> RunningHubWorkflowClient:
    def request_json(**request: object) -> Mapping[str, object]:
        calls.append(dict(request))
        return responses.pop(0)

    return RunningHubWorkflowClient(
        api_key="test-key",
        base_url="https://www.runninghub.ai",
        request_json=request_json,
        download_file=lambda **_kwargs: result_bytes,
        sleep=lambda _seconds: None,
        tts_config={
            "workflow_id": "wf-tts",
            "text_node_id": "10",
            "text_field": "text",
            "language_node_id": "11",
            "language_field": "locale",
            "speaker_node_id": "12",
            "speaker_field": "speaker",
            "timing_node_id": "13",
            "timing_field": "timing",
        },
    )


def test_language_only_tts_request_preserves_text_locale_speaker_and_timing() -> None:
    calls: list[dict[str, object]] = []
    client = _workflow_client(
        [
            {"code": 0, "taskId": "tts-task-1"},
            {
                "code": 0,
                "status": "SUCCESS",
                "results": [{"outputType": "mp3", "url": "https://cdn.example/line-1.mp3"}],
            },
        ],
        calls,
        result_bytes=b"ID3\x04\x00\x00audio",
    )

    result = client.run_tts(
        text="지금 사용해 보세요",
        language="ko-KR",
        speaker="creator-A",
        timing={"start_ms": 120, "end_ms": 1880},
    )

    assert calls[0]["url"] == "https://www.runninghub.ai/openapi/v2/run/workflow/wf-tts"
    assert calls[0]["payload"] == {
        "addMetadata": True,
        "nodeInfoList": [
            {"nodeId": "10", "fieldName": "text", "fieldValue": "지금 사용해 보세요"},
            {"nodeId": "11", "fieldName": "locale", "fieldValue": "ko-KR"},
            {"nodeId": "12", "fieldName": "speaker", "fieldValue": "creator-A"},
            {
                "nodeId": "13",
                "fieldName": "timing",
                "fieldValue": {"start_ms": 120, "end_ms": 1880},
            },
        ],
        "instanceType": "default",
        "usePersonalQueue": False,
    }
    assert result["task_id"] == "tts-task-1"
    assert result["audio_bytes"] == b"ID3\x04\x00\x00audio"
    assert result["result_url"] == "https://cdn.example/line-1.mp3"
    assert len(result["receipt"]["request_sha256"]) == 64
    assert len(result["receipt"]["response_sha256"]) == 64
    assert len(result["receipt"]["output_sha256"]) == 64


def test_language_only_lip_sync_request_uses_fixed_workflow_and_media_nodes() -> None:
    calls: list[dict[str, object]] = []
    client = _workflow_client(
        [
            {"code": 0, "taskId": "lip-task-1"},
            {
                "code": 0,
                "status": "SUCCESS",
                "results": [{"outputType": "mp4", "url": "https://cdn.example/line-1.mp4"}],
            },
        ],
        calls,
        result_bytes=b"\x00\x00\x00\x18ftypisomvideo",
    )

    result = client.run_final_lip_sync(
        audio_url="https://uploads.example/line-1.mp3",
        video_url="https://uploads.example/line-1.mp4",
    )

    assert calls[0]["url"].endswith("/openapi/v2/run/workflow/2080140197518823426")
    assert calls[0]["payload"]["nodeInfoList"] == [
        {
            "nodeId": "3",
            "fieldName": "audio",
            "fieldValue": "https://uploads.example/line-1.mp3",
            "description": "audio",
        },
        {
            "nodeId": "6",
            "fieldName": "video",
            "fieldValue": "https://uploads.example/line-1.mp4",
            "description": "video",
        },
    ]
    assert result["task_id"] == "lip-task-1"
    assert result["video_bytes"] == b"\x00\x00\x00\x18ftypisomvideo"
    assert result["result_url"] == "https://cdn.example/line-1.mp4"
    assert result["receipt"]["workflow_id"] == "2080140197518823426"
    assert len(result["receipt"]["request_sha256"]) == 64
    assert len(result["receipt"]["response_sha256"]) == 64
    assert len(result["receipt"]["output_sha256"]) == 64


class _TtsWorkflow:
    def __init__(self) -> None:
        self.calls: list[dict[str, object]] = []

    def run_tts(self, text: str, language: str, timing: Mapping[str, object], *, speaker: str) -> dict[str, object]:
        self.calls.append(
            {"text": text, "language": language, "timing": dict(timing), "speaker": speaker}
        )
        number = len(self.calls)
        audio = f"ID3-line-{number}".encode("utf-8")
        return {
            "task_id": f"tts-{number}",
            "result_url": f"https://cdn.example/line-{number}.mp3",
            "audio_bytes": audio,
            "receipt": {
                "schema_version": "runninghub-tts-workflow/v1",
                "task_id": f"tts-{number}",
                "request_sha256": "1" * 64,
                "response_sha256": "2" * 64,
                "output_sha256": hashlib.sha256(audio).hexdigest(),
                "language": language,
                "speaker": speaker,
                "timing": dict(timing),
            },
        }


class _ApprovalStore:
    def __init__(self, approval: Mapping[str, object]) -> None:
        self.approval = dict(approval)

    def get_script_approval(self, job_id: str, revision: int) -> Mapping[str, object]:
        assert job_id == "job-language"
        assert revision == 4
        return self.approval


class _PublishContext:
    def __init__(self, approval: Mapping[str, object]) -> None:
        self.job_id = "job-language"
        self.snapshot = SimpleNamespace(
            current_script_revision=4,
            approved_script_sha256="a" * 64,
            slots_manifest={"output_language": "ko-KR", "admission": {"language_only": True}},
        )
        self.job_store = _ApprovalStore(approval)
        self.published: list[dict[str, object]] = []

    def publish_bytes(self, **value: object) -> dict[str, object]:
        descriptor = {
            "artifact_id": f"artifact-{len(self.published)}",
            "kind": value["kind"],
            "sha256": value["expected_sha256"],
            "content_type": value["content_type"],
            "size_bytes": len(value["data"]),
            "metadata": value.get("metadata") or {},
            "data": value["data"],
        }
        self.published.append(descriptor)
        return descriptor

    @property
    def artifacts(self) -> tuple[Mapping[str, object], ...]:
        return tuple(self.published)


def _approved_lines() -> list[dict[str, object]]:
    return [
        {
            "line_id": "L01",
            "cut_id": "C01",
            "content_type": "spoken",
            "source_content_timeline_sha256": "b" * 64,
            "speaker": {"id": "creator-A", "role": "creator", "visibility": "on_camera"},
            "speaker_assignment": {"status": "CONFIRMED", "speaker_id": "creator-A"},
            "language": {"bcp47": "ko-KR", "script": "Kore"},
            "time": {"start_ms": 120, "end_ms": 1880},
            "text": {"exact": "지금 사용해 보세요"},
        },
        {
            "line_id": "L02",
            "cut_id": "C02",
            "content_type": "spoken",
            "source_content_timeline_sha256": "b" * 64,
            "speaker": {"id": "creator-B", "role": "friend", "visibility": "on_camera"},
            "speaker_assignment": {"status": "CONFIRMED", "speaker_id": "creator-B"},
            "language": {"bcp47": "ko-KR", "script": "Kore"},
            "time": {"start_ms": 1900, "end_ms": 3400},
            "text": {"exact": "정말 편리해요"},
        },
    ]


def _approval(lines: list[dict[str, object]]) -> dict[str, object]:
    raw = json.dumps(lines, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return {
        "contract": "approved-script-lines/v1",
        "revision": 4,
        "script_sha256": "a" * 64,
        "source_content_timeline_sha256": "b" * 64,
        "line_contracts": lines,
        "line_contracts_sha256": hashlib.sha256(raw).hexdigest(),
    }


def test_language_only_tts_stage_preserves_multiple_speakers_and_exact_windows() -> None:
    stage_class = getattr(packaged_stages, "TtsStage", None)
    assert stage_class is not None
    lines = _approved_lines()
    context = _PublishContext(_approval(lines))
    workflow = _TtsWorkflow()

    result = stage_class(workflow_client=workflow).run(context=context, input_artifacts=[])

    assert workflow.calls == [
        {
            "text": "지금 사용해 보세요",
            "language": "ko-KR",
            "timing": {"start_ms": 120, "end_ms": 1880},
            "speaker": "creator-A",
        },
        {
            "text": "정말 편리해요",
            "language": "ko-KR",
            "timing": {"start_ms": 1900, "end_ms": 3400},
            "speaker": "creator-B",
        },
    ]
    assert [item["metadata"]["speaker"] for item in context.published] == [
        "creator-A",
        "creator-B",
    ]
    assert len(result["localized_audio"]) == 2


def test_language_only_tts_stage_fails_closed_on_ambiguous_speaker() -> None:
    stage_class = getattr(packaged_stages, "TtsStage", None)
    assert stage_class is not None
    lines = _approved_lines()
    lines[1]["speaker_assignment"] = {"status": "PENDING_ASSIGNMENT"}
    context = _PublishContext(_approval(lines))
    workflow = _TtsWorkflow()

    with pytest.raises(ReplicationError, match="speaker assignment"):
        stage_class(workflow_client=workflow).run(context=context, input_artifacts=[])

    assert workflow.calls == []


def test_language_only_language_validation_binds_each_audio_to_exact_line() -> None:
    lines = _approved_lines()
    context = _PublishContext(_approval(lines))
    packaged_stages.TtsStage(workflow_client=_TtsWorkflow()).run(
        context=context, input_artifacts=[]
    )

    result = packaged_stages.TtsLanguageValidationStage().run(
        context=context, input_artifacts=[]
    )

    assert [row["line_id"] for row in result["language_validation"]["lines"]] == [
        "L01",
        "L02",
    ]
    assert all(
        row["utf8_validated"] is True
        and row["requested_language_validated"] is True
        for row in result["language_validation"]["lines"]
    )
    assert context.published[-1]["kind"] == "tts_language_validation"


class _LipSyncWorkflow:
    def __init__(self) -> None:
        self.uploads: list[bytes] = []
        self.calls: list[tuple[str, str]] = []

    def upload_media(self, path: Path) -> str:
        self.uploads.append(path.read_bytes())
        return f"https://uploads.example/media-{len(self.uploads)}"

    def run_final_lip_sync(self, audio_url: str, video_url: str) -> dict[str, object]:
        self.calls.append((audio_url, video_url))
        number = len(self.calls)
        video = b"\x00\x00\x00\x18ftypisomlocalized" + bytes([number])
        return {
            "task_id": f"lip-{number}",
            "result_url": f"https://cdn.example/lip-{number}.mp4",
            "video_bytes": video,
            "receipt": {
                "schema_version": "runninghub-final-lip-sync/v1",
                "task_id": f"lip-{number}",
                "workflow_id": "2080140197518823426",
                "request_sha256": "3" * 64,
                "response_sha256": "4" * 64,
                "output_sha256": hashlib.sha256(video).hexdigest(),
            },
        }


class _Materialized:
    def __init__(self, path: Path, sha256: str) -> None:
        self.path = path
        self.sha256 = sha256


class _PipelineContext(_PublishContext):
    def __init__(self, approval: Mapping[str, object], work_dir: Path) -> None:
        super().__init__(approval)
        self.work_dir = work_dir
        self.source = work_dir / "source.mp4"
        self.source.write_bytes(b"\x00\x00\x00\x18ftypisomsource")

    @contextmanager
    def materialize_slot(self, slot_id: str):
        assert slot_id == "source_video"
        yield _Materialized(self.source, hashlib.sha256(self.source.read_bytes()).hexdigest())

    @contextmanager
    def materialize_artifact(self, kind: str, *, artifact_id: str, sha256: str | None = None):
        artifact = next(
            item
            for item in self.published
            if item["kind"] == kind and item["artifact_id"] == artifact_id
        )
        assert sha256 is None or artifact["sha256"] == sha256
        path = self.work_dir / f"{artifact_id}.bin"
        path.write_bytes(artifact["data"])
        yield _Materialized(path, str(artifact["sha256"]))


def test_language_only_final_lip_sync_publishes_input_output_shas_and_receipt(tmp_path: Path) -> None:
    lines = _approved_lines()
    context = _PipelineContext(_approval(lines), tmp_path)
    packaged_stages.TtsStage(workflow_client=_TtsWorkflow()).run(
        context=context, input_artifacts=[]
    )
    packaged_stages.TtsLanguageValidationStage().run(
        context=context, input_artifacts=[]
    )
    workflow = _LipSyncWorkflow()

    def extract_window(*, source_path: Path, start_ms: int, end_ms: int, destination: Path) -> Path:
        assert source_path == context.source
        destination.write_bytes(
            b"\x00\x00\x00\x18ftypisomwindow"
            + f"{start_ms}-{end_ms}".encode("ascii")
        )
        return destination

    result = packaged_stages.FinalLipSyncStage(
        workflow_client=workflow,
        window_extractor=extract_window,
    ).run(context=context, input_artifacts=[])

    assert len(result["provider_videos"]) == 2
    assert len(workflow.calls) == 2
    assert all(len(item["input_audio_sha256"]) == 64 for item in result["provider_videos"])
    assert all(len(item["input_video_sha256"]) == 64 for item in result["provider_videos"])
    assert all(len(item["output_sha256"]) == 64 for item in result["provider_videos"])
    assert [item["kind"] for item in context.published].count("lip_sync_video_input") == 2
    assert [item["kind"] for item in context.published].count("provider_video") == 2
    assert [item["kind"] for item in context.published].count("final_lip_sync_receipt") == 2


def test_language_only_assembly_splices_exact_lip_sync_windows_without_seedance(tmp_path: Path) -> None:
    stage_class = getattr(packaged_stages, "LanguageOnlySpliceStage", None)
    assert stage_class is not None
    lines = _approved_lines()
    context = _PipelineContext(_approval(lines), tmp_path)
    packaged_stages.TtsStage(workflow_client=_TtsWorkflow()).run(context=context, input_artifacts=[])
    packaged_stages.TtsLanguageValidationStage().run(context=context, input_artifacts=[])
    workflow = _LipSyncWorkflow()

    def extract_window(*, source_path: Path, start_ms: int, end_ms: int, destination: Path) -> Path:
        destination.write_bytes(b"\x00\x00\x00\x18ftypisomwindow" + f"{start_ms}-{end_ms}".encode())
        return destination

    packaged_stages.FinalLipSyncStage(
        workflow_client=workflow,
        window_extractor=extract_window,
    ).run(context=context, input_artifacts=[])
    observed: dict[str, object] = {}

    def assemble(*, source_path: Path, windows: list[Mapping[str, object]], destination: Path) -> Path:
        observed.update({"source_path": source_path, "windows": windows})
        destination.write_bytes(b"\x00\x00\x00\x18ftypisomassembled")
        return destination

    class _DefaultSplice:
        def run(self, **_kwargs: object) -> Mapping[str, object]:
            raise AssertionError("language-only must not delegate to Seedance compositor bindings")

    result = stage_class(default_stage=_DefaultSplice(), assembler=assemble).run(
        context=context,
        input_artifacts=[],
    )

    assert observed["source_path"] == context.source
    assert [window["timing"] for window in observed["windows"]] == [
        {"start_ms": 120, "end_ms": 1880},
        {"start_ms": 1900, "end_ms": 3400},
    ]
    assert result["output_artifact"]["kind"] == "assembled_video"
    assert context.published[-1]["kind"] == "assembled_video"


def test_language_only_pipeline_stages_are_explicitly_registered() -> None:
    expected = ("run_tts", "validate_tts_language", "run_final_lip_sync")

    assert all(stage in POST_APPROVAL_STAGES for stage in expected)
    assert all(stage in EXECUTABLE_STAGES for stage in expected)


def test_language_only_tts_readiness_fails_closed_when_config_is_missing(monkeypatch: pytest.MonkeyPatch) -> None:
    names = (
        "RUNNINGHUB_TTS_WORKFLOW_ID",
        "RUNNINGHUB_TTS_TEXT_NODE_ID",
        "RUNNINGHUB_TTS_TEXT_FIELD",
        "RUNNINGHUB_TTS_LANGUAGE_NODE_ID",
        "RUNNINGHUB_TTS_LANGUAGE_FIELD",
        "RUNNINGHUB_TTS_SPEAKER_NODE_ID",
        "RUNNINGHUB_TTS_SPEAKER_FIELD",
        "RUNNINGHUB_TTS_TIMING_NODE_ID",
        "RUNNINGHUB_TTS_TIMING_FIELD",
        "RUNNINGHUB_TTS_TIMEOUT_SECONDS",
    )
    for name in names:
        monkeypatch.delenv(name, raising=False)

    with pytest.raises(packaged_ports.PackagedPortsError, match="RUNNINGHUB_TTS"):
        packaged_ports.runninghub_tts_config_from_environment()


def test_language_only_tts_readiness_returns_only_explicit_config(monkeypatch: pytest.MonkeyPatch) -> None:
    values = {
        "RUNNINGHUB_TTS_WORKFLOW_ID": "tts-workflow-42",
        "RUNNINGHUB_TTS_TEXT_NODE_ID": "10",
        "RUNNINGHUB_TTS_TEXT_FIELD": "text",
        "RUNNINGHUB_TTS_LANGUAGE_NODE_ID": "11",
        "RUNNINGHUB_TTS_LANGUAGE_FIELD": "locale",
        "RUNNINGHUB_TTS_SPEAKER_NODE_ID": "12",
        "RUNNINGHUB_TTS_SPEAKER_FIELD": "speaker",
        "RUNNINGHUB_TTS_TIMING_NODE_ID": "13",
        "RUNNINGHUB_TTS_TIMING_FIELD": "timing",
        "RUNNINGHUB_TTS_TIMEOUT_SECONDS": "240",
    }
    for name, value in values.items():
        monkeypatch.setenv(name, value)

    config, timeout = packaged_ports.runninghub_tts_config_from_environment()

    assert config == {
        "workflow_id": "tts-workflow-42",
        "text_node_id": "10",
        "text_field": "text",
        "language_node_id": "11",
        "language_field": "locale",
        "speaker_node_id": "12",
        "speaker_field": "speaker",
        "timing_node_id": "13",
        "timing_field": "timing",
    }
    assert timeout == 240.0
