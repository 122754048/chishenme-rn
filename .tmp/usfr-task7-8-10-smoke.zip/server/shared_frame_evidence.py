"""Content-addressed reuse of decoded source frames and ROI evidence."""

from __future__ import annotations

from dataclasses import asdict, dataclass
import hashlib
import json
from collections.abc import Mapping
from typing import Any

from .errors import ReplicationError


SHARED_FRAME_MANIFEST_CONTRACT = "usfr-shared-frame-manifest/v1"


def _key(value: Mapping[str, Any]) -> str:
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()


@dataclass(frozen=True)
class SharedFrameRef:
    object_key: str
    sha256: str
    source_sha256: str
    timestamp_us: int
    roi: tuple[int, int, int, int] | None


class SharedFrameEvidenceStore:
    """Deduplicate one `(source, timestamp, ROI)` decode across all stages."""

    def __init__(self, backend: Any, decoder: Any) -> None:
        self.backend = backend
        self.decoder = decoder

    def get_or_create(
        self,
        source: Any,
        *,
        timestamp_us: int,
        roi: tuple[int, int, int, int] | None = None,
    ) -> SharedFrameRef:
        source_sha256 = str(getattr(source, "sha256", "") or "").lower()
        if len(source_sha256) != 64:
            raise ReplicationError("CONTRACT_INVALID", "shared frame source SHA-256 is required")
        if isinstance(timestamp_us, bool) or not isinstance(timestamp_us, int) or timestamp_us < 0:
            raise ReplicationError("CONTRACT_INVALID", "shared frame timestamp is invalid")
        normalized_roi = None if roi is None else tuple(int(value) for value in roi)
        if normalized_roi is not None and len(normalized_roi) != 4:
            raise ReplicationError("CONTRACT_INVALID", "shared frame ROI must contain four integers")
        digest_key = _key({"source_sha256": source_sha256, "timestamp_us": timestamp_us, "roi": normalized_roi})
        existing = self.backend.get(digest_key)
        if existing is not None:
            return SharedFrameRef(**dict(existing))
        create = getattr(self.decoder, "decode_and_publish", None)
        if not callable(create):
            raise ReplicationError("CAPABILITY_UNAVAILABLE", "shared frame decoder is not configured", retryable=True)
        created = create(source, timestamp_us=timestamp_us, roi=normalized_roi)
        if isinstance(created, SharedFrameRef):
            candidate = created
        elif isinstance(created, Mapping):
            candidate = SharedFrameRef(**dict(created))
        else:
            raise ReplicationError("CONTRACT_INVALID", "shared frame decoder returned an invalid reference")
        if candidate.source_sha256 != source_sha256 or candidate.timestamp_us != timestamp_us or candidate.roi != normalized_roi:
            raise ReplicationError("CONTRACT_INVALID", "shared frame decoder reference does not match request")
        put_if_absent = getattr(self.backend, "put_if_absent", None)
        if not callable(put_if_absent):
            raise ReplicationError("CONTRACT_INVALID", "shared frame backend lacks atomic put_if_absent")
        stored = put_if_absent(digest_key, asdict(candidate))
        return SharedFrameRef(**dict(stored or asdict(candidate)))


def build_shared_frame_manifest(
    *, source_sha256: str, frames: list[Mapping[str, Any]]
) -> dict[str, Any]:
    """Freeze the exact reusable frame set for downstream control evidence."""

    normalized_source = str(source_sha256 or "").lower()
    if len(normalized_source) != 64:
        raise ReplicationError("CONTRACT_INVALID", "shared frame manifest source SHA-256 is required")
    rows: list[dict[str, Any]] = []
    seen: set[tuple[int, tuple[int, int, int, int] | None]] = set()
    for raw in frames:
        if not isinstance(raw, Mapping):
            raise ReplicationError("CONTRACT_INVALID", "shared frame manifest row is invalid")
        try:
            timestamp_us = int(raw.get("timestamp_us"))
        except (TypeError, ValueError) as exc:
            raise ReplicationError("CONTRACT_INVALID", "shared frame manifest timestamp is invalid") from exc
        roi_raw = raw.get("roi")
        roi = None if roi_raw is None else tuple(int(value) for value in roi_raw)
        if timestamp_us < 0 or (roi is not None and len(roi) != 4):
            raise ReplicationError("CONTRACT_INVALID", "shared frame manifest frame bounds are invalid")
        key = (timestamp_us, roi)
        if key in seen:
            raise ReplicationError("CONTRACT_INVALID", "shared frame manifest contains a duplicate frame")
        seen.add(key)
        sha256 = str(raw.get("sha256") or "").lower()
        artifact_id = str(raw.get("artifact_id") or "")
        object_key = str(raw.get("object_key") or "")
        if len(sha256) != 64 or not artifact_id or not object_key:
            raise ReplicationError("CONTRACT_INVALID", "shared frame manifest frame reference is invalid")
        rows.append({
            "timestamp_us": timestamp_us,
            "roi": list(roi) if roi is not None else None,
            "sha256": sha256,
            "artifact_id": artifact_id,
            "object_key": object_key,
        })
    if not rows:
        raise ReplicationError("CONTRACT_INVALID", "shared frame manifest requires at least one frame")
    rows.sort(key=lambda item: (item["timestamp_us"], tuple(item["roi"] or ())))
    manifest: dict[str, Any] = {
        "contract": SHARED_FRAME_MANIFEST_CONTRACT,
        "source_sha256": normalized_source,
        "frames": rows,
    }
    manifest["manifest_sha256"] = _key(manifest)
    return manifest


__all__ = [
    "SHARED_FRAME_MANIFEST_CONTRACT",
    "SharedFrameEvidenceStore",
    "SharedFrameRef",
    "build_shared_frame_manifest",
]
