"""Route-aware QC planning without weakening the final hard gates.

The final media always receives the same deterministic base checks.  Semantic
or model-assisted follow-up is restricted to the named factor that is below
its approved threshold; one failed factor is never authority to rerun every
unrelated QA dimension.
"""

from __future__ import annotations

import hashlib
import json
import re
from typing import Any, Mapping, Sequence


BASE_CHECKS = (
    "decode",
    "video_stream",
    "required_audio",
    "duration",
    "fps",
    "black_boundaries",
    "timeline_placement",
    "final_object_verification",
)

_SHA256 = re.compile(r"^[0-9a-f]{64}$")


def _canonical_sha256(value: Any) -> str:
    return hashlib.sha256(
        json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    ).hexdigest()


def _require_sha256(value: Any, label: str) -> str:
    normalized = str(value or "").lower()
    if _SHA256.fullmatch(normalized) is None:
        raise ValueError(f"{label} must be a lowercase SHA-256")
    return normalized


def _score(value: Any) -> float | None:
    if isinstance(value, Mapping):
        value = value.get("score")
    if isinstance(value, bool):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def build_qc_plan(
    *,
    route: str,
    hard_failures: Sequence[str],
    factor_scores: Mapping[str, Any],
    threshold: float = 90.0,
) -> dict[str, Any]:
    """Return the immutable final-QC execution plan.

    Missing or malformed factor evidence is escalated instead of silently
    accepted.  ``hard_failures`` remains blocking evidence and does not remove
    any base check.
    """

    normalized_threshold = float(threshold)
    escalated: list[str] = []
    for factor, raw_score in factor_scores.items():
        score = _score(raw_score)
        if score is None or score < normalized_threshold:
            escalated.append(str(factor))
    escalated.sort()
    return {
        "schema_version": "usfr-qc-plan/v1",
        "route": str(route or "unknown"),
        "base_checks": list(BASE_CHECKS),
        "hard_failures": [str(item) for item in hard_failures],
        "factor_threshold": normalized_threshold,
        "escalated_factors": escalated,
        "prohibited_full_rerun": True,
    }


def build_qc_receipt(
    *,
    plan: Mapping[str, Any],
    final_output_sha256: str,
    source_evidence_sha256s: Sequence[str],
    evaluator_identity: Mapping[str, Any],
    factor_scores: Mapping[str, Any],
) -> dict[str, Any]:
    """Bind a focused semantic-QC result to the exact final media and plan."""

    if plan.get("prohibited_full_rerun") is not True:
        raise ValueError("QC receipt requires prohibited_full_rerun plan")
    final_sha = _require_sha256(final_output_sha256, "final_output_sha256")
    sources = sorted({_require_sha256(item, "source_evidence_sha256") for item in source_evidence_sha256s})
    if not sources:
        raise ValueError("QC receipt requires source/evidence SHA-256")
    model_sha = _require_sha256(evaluator_identity.get("model_sha256"), "evaluator.model_sha256")
    evaluated = sorted(str(item) for item in plan.get("escalated_factors", []) if str(item))
    scores = {name: factor_scores[name] for name in evaluated if name in factor_scores}
    if set(scores) != set(evaluated):
        raise ValueError("QC receipt is missing escalated factor scores")
    return {
        "schema_version": "usfr-focused-qc-receipt/v1",
        "qc_plan_sha256": _canonical_sha256(dict(plan)),
        "final_output_sha256": final_sha,
        "source_evidence_sha256s": sources,
        "evaluator_model_sha256": model_sha,
        "factor_scores_sha256": _canonical_sha256(scores),
        "evaluated_factors": evaluated,
    }


def validate_focused_qc_result(
    *, plan: Mapping[str, Any], result: Mapping[str, Any]
) -> dict[str, Any]:
    """Reject recovery QC that broadens a factor-scoped escalation plan."""

    if plan.get("prohibited_full_rerun") is not True:
        raise ValueError("focused QC requires prohibited_full_rerun")
    if result.get("full_rerun") is not False:
        raise ValueError("focused QC must explicitly reject a full rerun")
    allowed = {str(item) for item in plan.get("escalated_factors", [])}
    evaluated_raw = result.get("evaluated_factors")
    if not isinstance(evaluated_raw, Sequence) or isinstance(evaluated_raw, (str, bytes, bytearray)):
        raise ValueError("focused QC requires evaluated_factors")
    evaluated = {str(item) for item in evaluated_raw}
    if not evaluated or not evaluated.issubset(allowed):
        raise ValueError("focused QC evaluated factors exceed the escalation plan")
    receipt = result.get("receipt")
    if not isinstance(receipt, Mapping):
        raise ValueError("focused QC requires an evidence-bound receipt")
    expected_plan_sha = _canonical_sha256(dict(plan))
    if receipt.get("schema_version") != "usfr-focused-qc-receipt/v1" or receipt.get("qc_plan_sha256") != expected_plan_sha:
        raise ValueError("focused QC receipt is not bound to the escalation plan")
    _require_sha256(receipt.get("final_output_sha256"), "receipt.final_output_sha256")
    source_hashes = receipt.get("source_evidence_sha256s")
    if not isinstance(source_hashes, Sequence) or isinstance(source_hashes, (str, bytes, bytearray)) or not source_hashes:
        raise ValueError("focused QC receipt requires source/evidence SHA-256")
    for value in source_hashes:
        _require_sha256(value, "receipt.source_evidence_sha256")
    _require_sha256(receipt.get("evaluator_model_sha256"), "receipt.evaluator_model_sha256")
    _require_sha256(receipt.get("factor_scores_sha256"), "receipt.factor_scores_sha256")
    receipt_factors = {str(item) for item in receipt.get("evaluated_factors", [])}
    if receipt_factors != evaluated:
        raise ValueError("focused QC receipt factors do not match the evaluator scope")
    return dict(result)


__all__ = [
    "BASE_CHECKS",
    "build_qc_plan",
    "build_qc_receipt",
    "validate_focused_qc_result",
]
