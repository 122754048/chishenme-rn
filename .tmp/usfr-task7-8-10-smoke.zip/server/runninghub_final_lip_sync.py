"""Canonical request builder for the final RunningHub audio-driven lip-sync.

Language localization and verified singing use the same workflow.  Upstream
stages decide whether a region is eligible; this module only freezes the exact
provider request and never performs a media upload or a paid submission.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from pathlib import Path
import shutil
import subprocess
from typing import Any


FINAL_LIP_SYNC_WORKFLOW_ID = "2080140197518823426"


def _media_input(value: object) -> str:
    result = str(value or "").strip()
    if not result:
        raise ValueError("RUNNINGHUB_FINAL_LIP_SYNC_MEDIA_REQUIRED")
    return result


def build_final_lip_sync_provider_request(
    *,
    audio_input: object,
    video_input: object,
) -> dict[str, Any]:
    """Build the only permitted final lip-sync request shape.

    Node 3 consumes the exact target-language or song-audio window, and node 6
    consumes the matching generated person-video window.  The output MP4 keeps
    the workflow's embedded audio; callers must not remux a different track.
    """

    audio = _media_input(audio_input)
    video = _media_input(video_input)
    return {
        "workflow_id": FINAL_LIP_SYNC_WORKFLOW_ID,
        "payload": {
            "nodeInfoList": [
                {
                    "nodeId": "3",
                    "fieldName": "audio",
                    "fieldValue": audio,
                    "description": "audio",
                },
                {
                    "nodeId": "6",
                    "fieldName": "video",
                    "fieldValue": video,
                    "description": "video",
                },
            ],
            "instanceType": "default",
            "usePersonalQueue": False,
        },
    }


def extract_final_lip_sync_window(
    *, source_path: Path, start_ms: int, end_ms: int, destination: Path
) -> Path:
    executable = shutil.which("ffmpeg")
    if not executable:
        raise RuntimeError("ffmpeg is required to extract final lip-sync windows")
    command = [
        executable, "-v", "error", "-y", "-ss", f"{start_ms / 1000:.3f}",
        "-i", str(source_path), "-t", f"{(end_ms - start_ms) / 1000:.3f}",
        "-an", "-c:v", "libx264", "-preset", "veryfast", "-crf", "18",
        "-pix_fmt", "yuv420p", str(destination),
    ]
    completed = subprocess.run(command, capture_output=True, check=False, timeout=180)
    if completed.returncode != 0 or not destination.is_file() or destination.stat().st_size <= 0:
        raise RuntimeError("ffmpeg could not extract the final lip-sync window")
    return destination


def assemble_final_lip_sync_windows(
    *, source_path: Path, windows: Sequence[Mapping[str, Any]], destination: Path
) -> Path:
    executable = shutil.which("ffmpeg")
    if not executable:
        raise RuntimeError("ffmpeg is required for final lip-sync assembly")
    command = [executable, "-v", "error", "-y", "-i", str(source_path)]
    for window in windows:
        command.extend(["-i", str(window["path"])])
    filters: list[str] = []
    concat_inputs: list[str] = []
    cursor_ms = 0
    part = 0

    def source_part(start_ms: int, end_ms: int | None) -> None:
        nonlocal part
        end = f":end={end_ms / 1000:.3f}" if end_ms is not None else ""
        filters.extend(
            (
                f"[0:v]trim=start={start_ms / 1000:.3f}{end},setpts=PTS-STARTPTS[v{part}]",
                f"[0:a]atrim=start={start_ms / 1000:.3f}{end},asetpts=PTS-STARTPTS[a{part}]",
            )
        )
        concat_inputs.append(f"[v{part}][a{part}]")
        part += 1

    for input_index, window in enumerate(windows, start=1):
        timing = window["timing"]
        start_ms, end_ms = int(timing["start_ms"]), int(timing["end_ms"])
        if start_ms > cursor_ms:
            source_part(cursor_ms, start_ms)
        duration = (end_ms - start_ms) / 1000
        filters.extend(
            (
                f"[{input_index}:v]trim=duration={duration:.3f},setpts=PTS-STARTPTS[v{part}]",
                f"[{input_index}:a]atrim=duration={duration:.3f},asetpts=PTS-STARTPTS[a{part}]",
            )
        )
        concat_inputs.append(f"[v{part}][a{part}]")
        part += 1
        cursor_ms = end_ms
    source_part(cursor_ms, None)
    filters.append(f"{''.join(concat_inputs)}concat=n={len(concat_inputs)}:v=1:a=1[v][a]")
    command.extend(
        [
            "-filter_complex", ";".join(filters), "-map", "[v]", "-map", "[a]",
            "-c:v", "libx264", "-preset", "veryfast", "-crf", "18", "-c:a", "aac",
            "-movflags", "+faststart", str(destination),
        ]
    )
    completed = subprocess.run(command, capture_output=True, check=False, timeout=300)
    if completed.returncode != 0 or not destination.is_file() or destination.stat().st_size <= 0:
        raise RuntimeError("ffmpeg final lip-sync assembly failed")
    return destination


__all__ = [
    "FINAL_LIP_SYNC_WORKFLOW_ID",
    "build_final_lip_sync_provider_request",
    "extract_final_lip_sync_window",
    "assemble_final_lip_sync_windows",
]
