from __future__ import annotations

from dataclasses import dataclass, field
from datetime import UTC, datetime
import time
from typing import Any


@dataclass
class MetricsSink:
    records: list[dict[str, Any]] = field(default_factory=list)

    def record(
        self,
        *,
        run_id: str,
        stage: str,
        status: str,
        duration_seconds: float,
        provider: bool = False,
        route: str = "unknown",
        attempt: int = 1,
        phase: str = "active",
        request_digest: str | None = None,
        provider_task_id: str | None = None,
        temporary_files: int = 0,
        temporary_bytes: int = 0,
        decoded_frames: int = 0,
        qc_escalations: int = 0,
    ) -> dict[str, Any]:
        record = {
            "run_id": run_id,
            "stage": stage,
            "status": status,
            "duration_seconds": round(float(duration_seconds), 6),
            "provider": bool(provider),
            "route": str(route or "unknown"),
            "attempt": int(attempt),
            "phase": str(phase or "active"),
            "request_digest": request_digest,
            "provider_task_id": provider_task_id,
            "temporary_files": int(temporary_files),
            "temporary_bytes": int(temporary_bytes),
            "decoded_frames": int(decoded_frames),
            "qc_escalations": int(qc_escalations),
            "recorded_at": datetime.now(UTC).isoformat(),
        }
        self.records.append(record)
        return record

    def build_run_report(
        self,
        run_id: str,
        *,
        quality: float,
        hard_failures: list[str],
        videos: int = 1,
        adaptive_manifest_files: int = 0,
    ) -> dict[str, Any]:
        """Export path-free baseline/candidate evidence from actual stage calls."""

        records = [dict(item) for item in self.records if item["run_id"] == run_id]
        calls: dict[str, int] = {}
        provider_calls: dict[str, int] = {}
        active_seconds = 0.0
        provider_wait_seconds = 0.0
        temporary_files = temporary_bytes = decoded_frames = qc_escalations = 0
        for item in records:
            stage = item["stage"]
            calls[stage] = calls.get(stage, 0) + 1
            duration = float(item["duration_seconds"])
            if item["phase"] == "wait":
                provider_wait_seconds += duration
            else:
                active_seconds += duration
            if item["provider"]:
                provider_calls[stage] = provider_calls.get(stage, 0) + 1
            temporary_files += item["temporary_files"]
            temporary_bytes += item["temporary_bytes"]
            decoded_frames += item["decoded_frames"]
            qc_escalations += item["qc_escalations"]
        return {
            "schema_version": "usfr-route-first-run-report/v1",
            "run_id": run_id,
            "route_class": records[0]["route"] if records else "standard",
            "quality": float(quality),
            "hard_failures": list(hard_failures),
            "videos": int(videos),
            "active_seconds": round(active_seconds, 6),
            "provider_wait_seconds": round(provider_wait_seconds, 6),
            "calls": calls,
            "provider_calls": provider_calls,
            "temporary_files": temporary_files,
            "temporary_bytes": temporary_bytes,
            "decoded_frames": decoded_frames,
            "qc_escalations": qc_escalations,
            "adaptive_manifest_files": int(adaptive_manifest_files or temporary_files),
            "records": records,
        }


class StageMeasurement:
    def __init__(self, sink: MetricsSink, *, run_id: str, stage: str, provider: bool = False) -> None:
        self.sink = sink
        self.run_id = run_id
        self.stage = stage
        self.provider = provider
        self.started = 0.0

    def __enter__(self) -> "StageMeasurement":
        self.started = time.monotonic()
        return self

    def __exit__(self, exc_type, exc_value, traceback) -> None:
        self.sink.record(
            run_id=self.run_id,
            stage=self.stage,
            status="failed" if exc_type else "succeeded",
            duration_seconds=time.monotonic() - self.started,
            provider=self.provider,
        )
