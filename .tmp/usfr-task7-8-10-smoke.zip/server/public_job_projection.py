from __future__ import annotations

import hashlib
import json
import re
import tempfile
from pathlib import Path
from typing import Any, Mapping

from .errors import ReplicationError


_STORYBOARD_LOGICAL_NAME = re.compile(r"^storyboards/segment_\d{2}_v\d+\.png$")


def _bound_artifact(
    *,
    job_store: Any,
    job_id: str,
    artifact_id: str,
    object_key: str,
    sha256: str,
    kind: str,
    content_type: str,
    metadata: Mapping[str, Any],
) -> Any:
    getter = getattr(job_store, "get_artifact", None)
    if not callable(getter):
        raise ReplicationError("REVIEW_CONTENT_UNAVAILABLE", "review artifact storage is unavailable", http_status=503)
    try:
        artifact = getter(job_id, artifact_id)
    except Exception as exc:
        raise ReplicationError("REVIEW_CONTENT_UNAVAILABLE", "review artifact storage is unavailable", http_status=503) from exc
    if artifact is None:
        raise ReplicationError("REVIEW_CONTENT_INVALID", "review artifact binding is invalid", http_status=409)
    actual_metadata = getattr(artifact, "metadata", None)
    prefix = f"temporary/{job_id}/stages/"
    if (
        str(getattr(artifact, "kind", "") or "") != kind
        or str(getattr(artifact, "object_key", "") or "") != object_key
        or not object_key.startswith(prefix)
        or str(getattr(artifact, "sha256", "") or "").lower() != sha256.lower()
        or str(getattr(artifact, "content_type", "") or "").lower() != content_type
        or not isinstance(actual_metadata, Mapping)
        or any(actual_metadata.get(key) != value for key, value in metadata.items())
    ):
        raise ReplicationError("REVIEW_CONTENT_INVALID", "review artifact binding is invalid", http_status=409)
    return artifact


def _read_revision_json(*, object_store: Any, job_id: str, manifest: Any) -> Mapping[str, Any]:
    if object_store is None or not callable(getattr(object_store, "download_to", None)):
        raise ReplicationError(
            "REVIEW_CONTENT_UNAVAILABLE",
            "review content storage is unavailable",
            category="storage",
            retryable=True,
            http_status=503,
        )
    prefix = f"temporary/{job_id}/"
    object_key = str(manifest.object_key or "")
    if not object_key.startswith(prefix):
        raise ReplicationError("REVIEW_CONTENT_INVALID", "review content is outside the job namespace", http_status=409)
    with tempfile.TemporaryDirectory(prefix="usfr-review-") as directory:
        destination = Path(directory) / "revision.json"
        object_store.download_to(
            object_key=object_key,
            destination=destination,
            expected_sha256=str(manifest.sha256),
        )
        raw = destination.read_bytes()
    if len(raw) > 2 * 1024 * 1024 or hashlib.sha256(raw).hexdigest() != str(manifest.sha256):
        raise ReplicationError("REVIEW_CONTENT_INVALID", "review content failed validation", http_status=409)
    try:
        value = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ReplicationError("REVIEW_CONTENT_INVALID", "review content is not valid UTF-8 JSON", http_status=409) from exc
    if not isinstance(value, Mapping):
        raise ReplicationError("REVIEW_CONTENT_INVALID", "review content is not an object", http_status=409)
    return value


def _script_review(*, job_store: Any, object_store: Any, job_id: str, manifest: Any) -> dict[str, Any]:
    del object_store
    artifact_id = str(getattr(manifest, "user_artifact_id", "") or "")
    key = str(getattr(manifest, "user_artifact_object_key", "") or "")
    sha256 = str(getattr(manifest, "user_artifact_sha256", "") or "")
    if not artifact_id or not key or not sha256:
        raise ReplicationError("REVIEW_CONTENT_INVALID", "script download binding is invalid", http_status=409)
    _bound_artifact(
        job_store=job_store,
        job_id=job_id,
        artifact_id=artifact_id,
        object_key=key,
        sha256=sha256,
        kind="user_script_markdown",
        content_type="text/markdown; charset=utf-8",
        metadata={
            "logical_name": "analysis/reverse_storyboard_script.md",
            "presentation": "file",
            "inline_chat_substitute_forbidden": True,
        },
    )
    return {
        "type": "script",
        "artifact": {
            "logical_name": "analysis/reverse_storyboard_script.md",
            "presentation": "file",
            "content_type": "text/markdown; charset=utf-8",
            "download_url": f"/api/v1/jobs/{job_id}/artifacts/analysis/reverse_storyboard_script.md",
        },
    }


def _storyboard_review(*, job_store: Any, object_store: Any, job_id: str, manifest: Any) -> dict[str, Any]:
    del object_store
    if (
        getattr(manifest, "presentation", None) != "image_set"
        or getattr(manifest, "approval_scope", None) != "all_segments_together"
        or getattr(manifest, "text_only_substitute_forbidden", None) is not True
    ):
        raise ReplicationError("REVIEW_CONTENT_INVALID", "storyboard review binding is invalid", http_status=409)
    images = []
    logical_names: set[str] = set()
    for cut in getattr(manifest, "cut_images", ()):
        key = str(getattr(cut, "object_key", "") or "")
        logical_name = str(getattr(cut, "logical_name", "") or "")
        if logical_name in logical_names:
            raise ReplicationError("REVIEW_CONTENT_INVALID", "duplicate storyboard logical name", http_status=409)
        logical_names.add(logical_name)
        images.append(
            {
                "artifact_id": str(getattr(cut, "artifact_id", "") or ""),
                "object_key": key,
                "sha256": str(getattr(cut, "sha256", "") or ""),
                "logical_name": logical_name,
            }
        )
    prefix = f"temporary/{job_id}/"
    if (
        not images
        or any(
            not item["object_key"].startswith(prefix)
            or _STORYBOARD_LOGICAL_NAME.fullmatch(item["logical_name"]) is None
            for item in images
        )
    ):
        raise ReplicationError("REVIEW_CONTENT_INVALID", "storyboard preview binding is invalid", http_status=409)
    public_images = []
    for image in images:
        _bound_artifact(
            job_store=job_store,
            job_id=job_id,
            artifact_id=image["artifact_id"],
            object_key=image["object_key"],
            sha256=str(image["sha256"]),
            kind="storyboard_image",
            content_type="image/png",
            metadata={
                "logical_name": image["logical_name"],
                "presentation": "image_set",
                "approval_scope": "all_segments_together",
                "text_only_substitute_forbidden": True,
                "storyboard_manifest_sha256": str(getattr(manifest, "sha256", "") or "").lower(),
            },
        )
        public_images.append(
            {
                "logical_name": image["logical_name"],
                "content_type": "image/png",
                "url": f"/api/v1/jobs/{job_id}/artifacts/{image['logical_name']}",
            }
        )
    return {
        "type": "storyboard",
        "artifact": {
            "presentation": "image_set",
            "approval_scope": "all_segments_together",
            "text_only_substitute_forbidden": True,
            "images": public_images,
        },
    }


def public_review_artifact(
    snapshot: Any,
    *,
    job_store: Any,
    job_id: str,
    logical_name: str,
) -> Any:
    """Resolve one current review artifact through its server-recorded binding."""

    script = job_store.get_current_revision(job_id, "script")
    if script is not None and getattr(snapshot, "approved_script_sha256", None) != script.sha256:
        if logical_name != "analysis/reverse_storyboard_script.md":
            raise ReplicationError("REVIEW_CONTENT_INVALID", "review artifact is unavailable", http_status=404)
        artifact_id = str(getattr(script, "user_artifact_id", "") or "")
        object_key = str(getattr(script, "user_artifact_object_key", "") or "")
        sha256 = str(getattr(script, "user_artifact_sha256", "") or "")
        if not artifact_id or not object_key or not sha256:
            raise ReplicationError("REVIEW_CONTENT_INVALID", "script download binding is invalid", http_status=409)
        return _bound_artifact(
            job_store=job_store,
            job_id=job_id,
            artifact_id=artifact_id,
            object_key=object_key,
            sha256=sha256,
            kind="user_script_markdown",
            content_type="text/markdown; charset=utf-8",
            metadata={
                "logical_name": "analysis/reverse_storyboard_script.md",
                "presentation": "file",
                "inline_chat_substitute_forbidden": True,
            },
        )
    storyboard = job_store.get_current_revision(job_id, "storyboard")
    if storyboard is not None and getattr(snapshot, "approved_storyboard_sha256", None) != storyboard.sha256:
        if (
            getattr(storyboard, "presentation", None) != "image_set"
            or getattr(storyboard, "approval_scope", None) != "all_segments_together"
            or getattr(storyboard, "text_only_substitute_forbidden", None) is not True
            or _STORYBOARD_LOGICAL_NAME.fullmatch(logical_name) is None
        ):
            raise ReplicationError("REVIEW_CONTENT_INVALID", "review artifact is unavailable", http_status=404)
        matches = [
            cut
            for cut in getattr(storyboard, "cut_images", ())
            if str(getattr(cut, "logical_name", "") or "") == logical_name
        ]
        if len(matches) != 1:
            raise ReplicationError("REVIEW_CONTENT_INVALID", "review artifact is unavailable", http_status=404)
        cut = matches[0]
        return _bound_artifact(
            job_store=job_store,
            job_id=job_id,
            artifact_id=str(getattr(cut, "artifact_id", "") or ""),
            object_key=str(getattr(cut, "object_key", "") or ""),
            sha256=str(getattr(cut, "sha256", "") or ""),
            kind="storyboard_image",
            content_type="image/png",
            metadata={
                "logical_name": logical_name,
                "presentation": "image_set",
                "approval_scope": "all_segments_together",
                "text_only_substitute_forbidden": True,
                "storyboard_manifest_sha256": str(getattr(storyboard, "sha256", "") or "").lower(),
            },
        )
    raise ReplicationError("REVIEW_CONTENT_INVALID", "review artifact is unavailable", http_status=404)


def project_public_job(snapshot: Any, *, job_store: Any | None = None, object_store: Any | None = None) -> dict[str, Any]:
    """Return the deliberately small public representation of a job."""

    job_id = str(snapshot.job_id)
    state = str(snapshot.state or "").upper()
    if state == "SUCCEEDED":
        final_ref = snapshot.final_ref
        metadata = final_ref.get("metadata") if isinstance(final_ref, Mapping) else None
        result_url = metadata.get("public_url") if isinstance(metadata, Mapping) else None
        if not isinstance(result_url, str) or not result_url.strip():
            raise ReplicationError(
                "FINAL_URL_UNAVAILABLE",
                "final video URL is unavailable",
                category="delivery",
                retryable=True,
                http_status=503,
            )
        return {
            "job_id": job_id,
            "status": "completed",
            "result_url": result_url.strip(),
        }
    pending = getattr(snapshot, "pending_review_request", None)
    if isinstance(pending, Mapping):
        stage = "script_generation" if pending.get("kind") == "script" else "storyboard_generation"
        return {"job_id": job_id, "status": "processing", "stage": stage}
    if job_store is not None:
        script = job_store.get_current_revision(job_id, "script")
        if script is not None and snapshot.approved_script_sha256 != script.sha256:
            return {
                "job_id": job_id,
                "status": "waiting_review",
                "stage": "script",
                "review": _script_review(job_store=job_store, object_store=object_store, job_id=job_id, manifest=script),
            }
        storyboard = job_store.get_current_revision(job_id, "storyboard")
        if storyboard is not None and snapshot.approved_storyboard_sha256 != storyboard.sha256:
            return {
                "job_id": job_id,
                "status": "waiting_review",
                "stage": "storyboard",
                "review": _storyboard_review(job_store=job_store, object_store=object_store, job_id=job_id, manifest=storyboard),
            }
    if state == "IMPORTING":
        return {"job_id": job_id, "status": "importing"}
    if state == "FAILED":
        public_error = getattr(snapshot, "public_error", None)
        if isinstance(public_error, Mapping):
            return {"job_id": job_id, "status": "failed", "error": dict(public_error)}
        return {
            "job_id": job_id,
            "status": "failed",
            "error": {
                "code": "PROCESSING_FAILED",
                "message": "video generation failed",
                "retryable": False,
            },
        }
    return {"job_id": job_id, "status": "processing"}


__all__ = ["project_public_job", "public_review_artifact"]
