"""Build a clean, fingerprinted deployment ZIP from an explicit package root."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import shutil
import tempfile
import zipfile

try:
    from scripts.build_release_manifest import _forbidden_entry, _is_excluded, _safety_failures, verify_release_manifest
    from scripts.verify_bundle import verify_bundle
except ModuleNotFoundError:  # Direct execution from the scripts directory.
    from build_release_manifest import _forbidden_entry, _is_excluded, _safety_failures, verify_release_manifest
    from verify_bundle import verify_bundle


def archive_entries(root: Path) -> list[str]:
    """Return the deterministic, safety-filtered archive manifest."""

    entries: list[str] = []
    for path in root.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(root)
        if _is_excluded(relative) or _forbidden_entry(relative) is not None:
            continue
        if ".git" in relative.parts or relative.parts[0] == "exports":
            continue
        entries.append(relative.as_posix())
    return sorted(entries)


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def package_release(
    *,
    source_root: Path,
    output: Path,
    baseline_root: Path | None = None,
    readiness_status: str,
    test_status: str,
    docker_status: str,
    provider_status: str,
) -> dict[str, object]:
    """Stage, verify, archive, and sidecar the release evidence without secrets."""

    source_root = source_root.resolve()
    output = output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="usfr-release-staging-", dir=str(output.parent)) as temporary:
        staging = Path(temporary) / "bundle"
        staging.mkdir()
        for entry in archive_entries(source_root):
            source = source_root / entry
            target = staging / entry
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
        failures = [*_safety_failures(staging), *verify_bundle(staging)]
        if baseline_root is not None:
            failures.extend(verify_release_manifest(baseline_root, staging))
        if failures:
            raise ValueError("clean staging verification failed: " + "; ".join(sorted(set(failures))))
        with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            for entry in archive_entries(staging):
                archive.write(staging / entry, arcname=entry)
    fingerprint = {
        "schema_version": "usfr-release-fingerprint/v1",
        "zip": output.name,
        "zip_sha256": _sha256(output),
        "runtime_manifest_sha256": _sha256(source_root / "references" / "runtime_skill_manifest.json"),
        "readiness_status": readiness_status,
        "test_status": test_status,
        "docker_status": docker_status,
        "provider_status": provider_status,
        "archive_entries": archive_entries(source_root),
    }
    sidecar = output.with_suffix(output.suffix + ".release.json")
    sidecar.write_text(json.dumps(fingerprint, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return {"archive": str(output), "fingerprint": str(sidecar), **fingerprint}


def main() -> int:
    parser = argparse.ArgumentParser(description="Create a cache-free USFR deployment ZIP.")
    parser.add_argument("--source-root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--baseline-root", type=Path, help="optional external source baseline for SHA comparison")
    parser.add_argument("--readiness-status", default="not_run")
    parser.add_argument("--test-status", default="not_run")
    parser.add_argument("--docker-status", default="not_run")
    parser.add_argument("--provider-status", default="not_run")
    args = parser.parse_args()
    result = package_release(
        source_root=args.source_root,
        output=args.output,
        baseline_root=args.baseline_root,
        readiness_status=args.readiness_status,
        test_status=args.test_status,
        docker_status=args.docker_status,
        provider_status=args.provider_status,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
