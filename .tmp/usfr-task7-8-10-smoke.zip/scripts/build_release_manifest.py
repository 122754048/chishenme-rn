"""Verify that an allowlisted deployment bundle matches a source baseline."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
from typing import Any


_CACHE_DIRECTORIES = frozenset({"__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache"})
_USER_ARTIFACT_DIRECTORIES = frozenset({"replication_runs", "validation_runs", "user_assets", "uploads"})
_SECRET_FILE_NAMES = re.compile(r"(?:^|[._-])(?:secret|credential|private[_-]?key)(?:[._-]|$)", re.IGNORECASE)
_CREDENTIAL_ASSIGNMENT = re.compile(
    r"(?im)^[ \t]*(?:export[ \t]+)?(?:[A-Z][A-Z0-9_]*_)?(?:API_KEY|ACCESS_KEY|SECRET|TOKEN|PASSWORD|PRIVATE_KEY)[ \t]*=[ \t]*([^\r\n#]*)"
)
_PRIVATE_KEY = re.compile(r"-----BEGIN (?:[A-Z ]+ )?PRIVATE KEY-----")
_BEARER_TOKEN = re.compile(r"(?im)^\s*(?:authorization\s*[:=]\s*)?bearer\s+[A-Za-z0-9._~-]{8,}\s*$")
_WORKSTATION_PATH = re.compile(r"[A-Za-z]:[\\/]+(?:Users|home)[\\/]", re.IGNORECASE)
_SHA256 = re.compile(r"^[0-9a-f]{64}$")


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _is_excluded(relative: Path) -> bool:
    parts = set(relative.parts)
    if parts & _CACHE_DIRECTORIES or parts & _USER_ARTIFACT_DIRECTORIES:
        return True
    return relative.suffix == ".pyc" or relative.name == ".env" or relative.name.startswith(".env.") and relative.name != ".env.example"


def _manifest_paths(package_root: Path) -> list[Path]:
    manifest_path = package_root / "references" / "bundle_manifest.json"
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise ValueError(f"invalid bundle manifest: {exc}") from exc
    if not isinstance(manifest, dict):
        raise ValueError("invalid bundle manifest: root must be an object")
    paths: set[Path] = set()
    for section in ("runtime_files", "release_tools"):
        entries = manifest.get(section, [])
        if not isinstance(entries, list):
            raise ValueError(f"invalid bundle manifest: {section} must be a list")
        for entry in entries:
            relative = entry.get("path") if isinstance(entry, dict) else None
            candidate = Path(relative) if isinstance(relative, str) else None
            if candidate is None or candidate.is_absolute() or ".." in candidate.parts:
                raise ValueError(f"invalid bundle manifest path: {relative!r}")
            if _is_excluded(candidate):
                raise ValueError(f"forbidden bundle manifest path: {candidate.as_posix()}")
            paths.add(candidate)
    return sorted(paths, key=lambda path: path.as_posix())


def _compatibility_overrides(package_root: Path) -> dict[Path, tuple[str, str]]:
    manifest = json.loads((package_root / "references" / "bundle_manifest.json").read_text(encoding="utf-8"))
    records = manifest.get("source_baseline_overrides", [])
    if not isinstance(records, list):
        raise ValueError("invalid bundle manifest: source_baseline_overrides must be a list")
    overrides: dict[Path, tuple[str, str]] = {}
    for record in records:
        if not isinstance(record, dict):
            raise ValueError("invalid source baseline override")
        relative = Path(record.get("path")) if isinstance(record.get("path"), str) else None
        source_hash = str(record.get("source_sha256") or "").lower()
        package_hash = str(record.get("package_sha256") or "").lower()
        reason = record.get("reason")
        if (
            relative is None
            or relative.is_absolute()
            or ".." in relative.parts
            or _SHA256.fullmatch(source_hash) is None
            or _SHA256.fullmatch(package_hash) is None
            or not isinstance(reason, str)
            or not reason.strip()
            or relative in overrides
        ):
            raise ValueError("invalid source baseline override")
        overrides[relative] = (source_hash, package_hash)
    return overrides


def _package_only_files(package_root: Path) -> dict[Path, str]:
    manifest = json.loads((package_root / "references" / "bundle_manifest.json").read_text(encoding="utf-8"))
    records = manifest.get("source_package_only_files", [])
    if not isinstance(records, list):
        raise ValueError("invalid bundle manifest: source_package_only_files must be a list")
    declarations: dict[Path, str] = {}
    for record in records:
        if not isinstance(record, dict):
            raise ValueError("invalid source package-only declaration")
        relative = Path(record.get("path")) if isinstance(record.get("path"), str) else None
        reason = record.get("reason")
        if (
            relative is None
            or relative.is_absolute()
            or ".." in relative.parts
            or not isinstance(reason, str)
            or not reason.strip()
            or relative in declarations
        ):
            raise ValueError("invalid source package-only declaration")
        declarations[relative] = reason.strip()
    return declarations


def _is_placeholder(value: str) -> bool:
    normalized = value.strip().strip("'\"")
    lowered = normalized.casefold()
    return (
        not normalized
        or normalized.startswith("${")
        or normalized.startswith("$")
        or normalized.startswith("<")
        or lowered in {"none", "null", "false", "example"}
        or lowered.startswith(("change", "replace", "your_", "your-", "os.getenv", "os.environ", "config.", "self."))
    )


def _is_literal_credential(value: str) -> bool:
    raw = value.strip()
    if raw.startswith(("b'", 'b\"')):
        return False
    if raw.startswith(("'", '\"')) and raw.endswith(raw[:1]):
        return not _is_placeholder(raw)
    return bool(re.fullmatch(r"[A-Za-z0-9._~-]{8,}", raw)) and not _is_placeholder(raw)


def _secret_bearing(path: Path, text: str) -> bool:
    if path.name != ".env.example" and (path.name == ".env" or _SECRET_FILE_NAMES.search(path.name)):
        return True
    if _PRIVATE_KEY.search(text) or _BEARER_TOKEN.search(text):
        return True
    for match in _CREDENTIAL_ASSIGNMENT.finditer(text):
        if _is_literal_credential(match.group(1)):
            return True
    return False


def _forbidden_entry(relative: Path) -> str | None:
    parts = set(relative.parts)
    if parts & _CACHE_DIRECTORIES or relative.suffix == ".pyc":
        return "forbidden cache entry"
    if parts & _USER_ARTIFACT_DIRECTORIES:
        return "forbidden user artifact"
    if relative.name == ".env" or (relative.name.startswith(".env.") and relative.name != ".env.example"):
        return "secret-bearing packaged file"
    return None


def _safety_failures(package_root: Path) -> list[str]:
    failures: list[str] = []
    for path in package_root.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(package_root)
        forbidden = _forbidden_entry(relative)
        if forbidden is not None:
            failures.append(f"{forbidden}: {relative.as_posix()}")
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        rendered = relative.as_posix()
        if path.suffix.casefold() in {".py", ".json", ".yaml", ".yml", ".toml"} and _WORKSTATION_PATH.search(text):
            failures.append(f"workstation path in packaged file: {rendered}")
        if _secret_bearing(path, text):
            failures.append(f"secret-bearing packaged file: {rendered}")
    return failures


def verify_release_manifest(source_root: Path, package_root: Path) -> list[str]:
    """Return deterministic release-baseline violations for packaged files.

    The package manifest is the allowlist.  Package-only release adapters can
    legitimately have no counterpart in the older functional baseline, so
    only paths present in both roots are byte-compared.
    """

    source_root = source_root.resolve()
    package_root = package_root.resolve()
    failures = _safety_failures(package_root)
    try:
        allowlisted = _manifest_paths(package_root)
        overrides = _compatibility_overrides(package_root)
        package_only = _package_only_files(package_root)
    except ValueError as exc:
        return failures + [str(exc)]
    allowlisted_set = set(allowlisted)
    if any(path not in allowlisted_set for path in overrides):
        return failures + ["source baseline override is not allowlisted"]
    if any(path not in allowlisted_set for path in package_only):
        return failures + ["source package-only declaration is not allowlisted"]
    seen_package_only: set[Path] = set()
    for relative in allowlisted:
        packaged = package_root / relative
        source = source_root / relative
        rendered = relative.as_posix()
        if not packaged.is_file():
            failures.append(f"missing allowlisted package file: {rendered}")
        elif source.is_file():
            if relative in package_only:
                failures.append(f"stale source package-only declaration: {rendered}")
            source_hash, package_hash = _sha256(source), _sha256(packaged)
            override = overrides.get(relative)
            if source_hash == package_hash and override is not None:
                failures.append(f"stale source baseline override: {rendered}")
            elif source_hash != package_hash and override != (source_hash, package_hash):
                failures.append(f"SHA-256 mismatch: {rendered}")
        else:
            if relative in overrides:
                failures.append(f"stale source baseline override: {rendered}")
            if relative not in package_only:
                failures.append(f"source-absent package file is not declared package-only: {rendered}")
            else:
                seen_package_only.add(relative)
    for relative in package_only:
        if relative not in seen_package_only:
            failures.append(f"stale source package-only declaration: {relative.as_posix()}")
    return sorted(set(failures))


def main() -> int:
    parser = argparse.ArgumentParser(description="Compare allowlisted release bytes with a source baseline.")
    parser.add_argument("--source-root", required=True, type=Path)
    parser.add_argument("--package-root", required=True, type=Path)
    args = parser.parse_args()
    failures = verify_release_manifest(args.source_root, args.package_root)
    if failures:
        raise SystemExit("\n".join(failures))
    print("release manifest is valid")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
